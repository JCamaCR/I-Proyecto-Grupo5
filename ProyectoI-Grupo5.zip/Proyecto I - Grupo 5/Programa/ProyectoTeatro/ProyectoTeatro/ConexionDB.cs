﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.CodeDom;

namespace ProyectoTeatro
{
    internal class ConexionDB
    {
        string cadena = "Data Source = SJOMCC-NW12312\\SQLEXPRESS; Initial Catalog = Teatro;Integrated Security = True";
        public SqlConnection ConectarDB = new SqlConnection();

        public ConexionDB()
        {
            ConectarDB.ConnectionString = cadena;
        }

        public void abrir()
        {           
            try
            {
                ConectarDB.Open();
                Console.WriteLine("Conexión abierta");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error en la conexión: " + ex.Message);
            }
            
        }
        public void cerrar()
        {
            ConectarDB.Close();
        }

        public void Reservar(int i, int j, string nom)
        { 
            DataSet dataSet = new DataSet();                                  
            SqlCommand cmd1 = new SqlCommand("INSERT INTO Reservas(Fila,Columna,Nombre_Cliente) values ("+i+","+j+",'"+nom+"')", ConectarDB);
            cmd1.ExecuteNonQuery();
            SqlCommand cmd = new SqlCommand("UPDATE Asientos SET Estado = 1 WHERE Fila = " + i + " and Columna = " + j, ConectarDB);
            cmd.ExecuteNonQuery();
        }

        public void CancelarReserva(int i, int j)
        {
            DataSet dataSet = new DataSet();
            SqlCommand cmd1 = new SqlCommand("DELETE FROM Reservas WHERE Fila = " + i + " and Columna = " + j, ConectarDB);
            cmd1.ExecuteNonQuery();
            SqlCommand cmd = new SqlCommand("UPDATE Asientos SET Estado = 0 WHERE Fila = " + i + " and Columna = " + j, ConectarDB);
            cmd.ExecuteNonQuery();
        }

        public void BorrarDB()
        {
            int i,j = 0;
            DataSet dataSet = new DataSet();
            SqlCommand cmd1 = new SqlCommand("DELETE FROM Reservas", ConectarDB);
            cmd1.ExecuteNonQuery();
            for (i = 0; i < 10; i++)
            {
                for (j = 0; j < 15; j++)
                {
                    SqlCommand cmd = new SqlCommand("UPDATE Asientos SET Estado = 0 WHERE Fila = " + i + " and Columna = " + j, ConectarDB);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public int EstadoAsiento(int i,int j)
        {
            int esta = 0;
            string texto = "";            
            string cadena = ("SELECT Estado FROM Asientos WHERE Fila = "+i+ " and Columna = "+j);
            SqlCommand cmd = new SqlCommand(cadena, ConectarDB);
            SqlDataReader registro = cmd.ExecuteReader();
            if (registro.Read())
            {
                texto = registro["Estado"].ToString();
                esta = Int32.Parse(texto);
                registro.Close();
                return esta;
            }
            registro.Close();
            return esta;
        }
        public void CargaMatriz()
        {
            int esta,i,j,cont = 0;
            string texto = "";
            int[,] M = new int[10, 15];
            for (i = 0; i < 10; i++)
            {
                for (j = 0; j < 15; j++)
                {
                    string cadena = ("SELECT Estado FROM Asientos WHERE Fila = "+i+" and Columna = "+j);
                    SqlCommand cmd = new SqlCommand(cadena, ConectarDB);
                    SqlDataReader registro = cmd.ExecuteReader();
                    if (registro.Read())
                    {
                        texto = registro["Estado"].ToString();
                        esta = Int32.Parse(texto);
                        M[i,j] = esta;
                        //cont++;
                        //Console.WriteLine(""+cont+"   "+i+"  "+j+"   Estado: " +M[i,j]);
                    }
                    registro.Close();
                }
            }            
        }

        public int AsientoF(string boton)
        {
            string fil = "";
            int fi = 0;
            fil = boton.Substring(3, 1);           
            switch (fil)
            {
                case "A":
                    fi = 0;
                break;
                case "B":
                    fi = 1;
                break;
                case "C":
                    fi = 2;
                break;
                case "D":
                    fi = 3;
                break;
                case "E":
                    fi = 4;
                break;
                case "F":
                    fi = 5;
                break;
                case "G":
                    fi = 6;
                break;
                case "H":
                    fi = 7;
                break;
                case "I":
                    fi = 8;
                break;
                case "J":
                    fi = 9;
                break;
            }          
            return fi;
        }

        public int AsientoC(string boton)
        {
            string colu = "";
            int co = 0;                   
            colu = boton.Substring(4);
            co = Int32.Parse(colu);
            co = co - 1;
            return co;
        }

        public string NombreReserva(int Fil, int Col)
        {
            string texto = "";
            string cadena = ("SELECT Nombre_Cliente FROM Reservas WHERE Fila = " + Fil + " and Columna = " + Col);
            SqlCommand cmd = new SqlCommand(cadena, ConectarDB);
            SqlDataReader registro = cmd.ExecuteReader();
            if (registro.Read())
            {
                texto = registro["Nombre_Cliente"].ToString();
            }
            return texto;
        }
    }
}

