﻿namespace ProyectoTeatro
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BTNJ15 = new System.Windows.Forms.Button();
            this.BTNJ14 = new System.Windows.Forms.Button();
            this.BTNJ13 = new System.Windows.Forms.Button();
            this.BTNJ12 = new System.Windows.Forms.Button();
            this.BTNJ11 = new System.Windows.Forms.Button();
            this.BTNJ10 = new System.Windows.Forms.Button();
            this.BTNJ9 = new System.Windows.Forms.Button();
            this.BTNJ8 = new System.Windows.Forms.Button();
            this.BTNJ7 = new System.Windows.Forms.Button();
            this.BTNJ6 = new System.Windows.Forms.Button();
            this.BTNJ5 = new System.Windows.Forms.Button();
            this.BTNJ4 = new System.Windows.Forms.Button();
            this.BTNJ3 = new System.Windows.Forms.Button();
            this.BTNJ2 = new System.Windows.Forms.Button();
            this.BTNJ1 = new System.Windows.Forms.Button();
            this.BTNI15 = new System.Windows.Forms.Button();
            this.BTNI14 = new System.Windows.Forms.Button();
            this.BTNI13 = new System.Windows.Forms.Button();
            this.BTNI12 = new System.Windows.Forms.Button();
            this.BTNI11 = new System.Windows.Forms.Button();
            this.BTNI10 = new System.Windows.Forms.Button();
            this.BTNI9 = new System.Windows.Forms.Button();
            this.BTNI8 = new System.Windows.Forms.Button();
            this.BTNI7 = new System.Windows.Forms.Button();
            this.BTNI6 = new System.Windows.Forms.Button();
            this.BTNI5 = new System.Windows.Forms.Button();
            this.BTNI4 = new System.Windows.Forms.Button();
            this.BTNI3 = new System.Windows.Forms.Button();
            this.BTNI2 = new System.Windows.Forms.Button();
            this.BTNI1 = new System.Windows.Forms.Button();
            this.BTNH15 = new System.Windows.Forms.Button();
            this.BTNH14 = new System.Windows.Forms.Button();
            this.BTNH13 = new System.Windows.Forms.Button();
            this.BTNH12 = new System.Windows.Forms.Button();
            this.BTNH11 = new System.Windows.Forms.Button();
            this.BTNH10 = new System.Windows.Forms.Button();
            this.BTNH9 = new System.Windows.Forms.Button();
            this.BTNH8 = new System.Windows.Forms.Button();
            this.BTNH7 = new System.Windows.Forms.Button();
            this.BTNH6 = new System.Windows.Forms.Button();
            this.BTNH5 = new System.Windows.Forms.Button();
            this.BTNH4 = new System.Windows.Forms.Button();
            this.BTNH3 = new System.Windows.Forms.Button();
            this.BTNH2 = new System.Windows.Forms.Button();
            this.BTNH1 = new System.Windows.Forms.Button();
            this.BTNG15 = new System.Windows.Forms.Button();
            this.BTNG14 = new System.Windows.Forms.Button();
            this.BTNG13 = new System.Windows.Forms.Button();
            this.BTNG12 = new System.Windows.Forms.Button();
            this.BTNG11 = new System.Windows.Forms.Button();
            this.BTNG10 = new System.Windows.Forms.Button();
            this.BTNG9 = new System.Windows.Forms.Button();
            this.BTNG8 = new System.Windows.Forms.Button();
            this.BTNG7 = new System.Windows.Forms.Button();
            this.BTNG6 = new System.Windows.Forms.Button();
            this.BTNG5 = new System.Windows.Forms.Button();
            this.BTNG4 = new System.Windows.Forms.Button();
            this.BTNG3 = new System.Windows.Forms.Button();
            this.BTNG2 = new System.Windows.Forms.Button();
            this.BTNG1 = new System.Windows.Forms.Button();
            this.BTNF15 = new System.Windows.Forms.Button();
            this.BTNF14 = new System.Windows.Forms.Button();
            this.BTNF13 = new System.Windows.Forms.Button();
            this.BTNF12 = new System.Windows.Forms.Button();
            this.BTNF11 = new System.Windows.Forms.Button();
            this.BTNF10 = new System.Windows.Forms.Button();
            this.BTNF9 = new System.Windows.Forms.Button();
            this.BTNF8 = new System.Windows.Forms.Button();
            this.BTNF7 = new System.Windows.Forms.Button();
            this.BTNF6 = new System.Windows.Forms.Button();
            this.BTNF5 = new System.Windows.Forms.Button();
            this.BTNF4 = new System.Windows.Forms.Button();
            this.BTNF3 = new System.Windows.Forms.Button();
            this.BTNF2 = new System.Windows.Forms.Button();
            this.BTNF1 = new System.Windows.Forms.Button();
            this.BTNE15 = new System.Windows.Forms.Button();
            this.BTNE14 = new System.Windows.Forms.Button();
            this.BTNE13 = new System.Windows.Forms.Button();
            this.BTNE12 = new System.Windows.Forms.Button();
            this.BTNE11 = new System.Windows.Forms.Button();
            this.BTNE10 = new System.Windows.Forms.Button();
            this.BTNE9 = new System.Windows.Forms.Button();
            this.BTNE8 = new System.Windows.Forms.Button();
            this.BTNE7 = new System.Windows.Forms.Button();
            this.BTNE6 = new System.Windows.Forms.Button();
            this.BTNE5 = new System.Windows.Forms.Button();
            this.BTNE4 = new System.Windows.Forms.Button();
            this.BTNE3 = new System.Windows.Forms.Button();
            this.BTNE2 = new System.Windows.Forms.Button();
            this.BTNE1 = new System.Windows.Forms.Button();
            this.BTND15 = new System.Windows.Forms.Button();
            this.BTND14 = new System.Windows.Forms.Button();
            this.BTND13 = new System.Windows.Forms.Button();
            this.BTND12 = new System.Windows.Forms.Button();
            this.BTND11 = new System.Windows.Forms.Button();
            this.BTND10 = new System.Windows.Forms.Button();
            this.BTND9 = new System.Windows.Forms.Button();
            this.BTND8 = new System.Windows.Forms.Button();
            this.BTND7 = new System.Windows.Forms.Button();
            this.BTND6 = new System.Windows.Forms.Button();
            this.BTND5 = new System.Windows.Forms.Button();
            this.BTND4 = new System.Windows.Forms.Button();
            this.BTND3 = new System.Windows.Forms.Button();
            this.BTND2 = new System.Windows.Forms.Button();
            this.BTND1 = new System.Windows.Forms.Button();
            this.BTNC15 = new System.Windows.Forms.Button();
            this.BTNC14 = new System.Windows.Forms.Button();
            this.BTNC13 = new System.Windows.Forms.Button();
            this.BTNC12 = new System.Windows.Forms.Button();
            this.BTNC11 = new System.Windows.Forms.Button();
            this.BTNC10 = new System.Windows.Forms.Button();
            this.BTNC9 = new System.Windows.Forms.Button();
            this.BTNC8 = new System.Windows.Forms.Button();
            this.BTNC7 = new System.Windows.Forms.Button();
            this.BTNC6 = new System.Windows.Forms.Button();
            this.BTNC5 = new System.Windows.Forms.Button();
            this.BTNC4 = new System.Windows.Forms.Button();
            this.BTNC3 = new System.Windows.Forms.Button();
            this.BTNC2 = new System.Windows.Forms.Button();
            this.BTNC1 = new System.Windows.Forms.Button();
            this.BTNB15 = new System.Windows.Forms.Button();
            this.BTNB14 = new System.Windows.Forms.Button();
            this.BTNB13 = new System.Windows.Forms.Button();
            this.BTNB12 = new System.Windows.Forms.Button();
            this.BTNB11 = new System.Windows.Forms.Button();
            this.BTNB10 = new System.Windows.Forms.Button();
            this.BTNB9 = new System.Windows.Forms.Button();
            this.BTNB8 = new System.Windows.Forms.Button();
            this.BTNB7 = new System.Windows.Forms.Button();
            this.BTNB6 = new System.Windows.Forms.Button();
            this.BTNB5 = new System.Windows.Forms.Button();
            this.BTNB4 = new System.Windows.Forms.Button();
            this.BTNB3 = new System.Windows.Forms.Button();
            this.BTNB2 = new System.Windows.Forms.Button();
            this.BTNB1 = new System.Windows.Forms.Button();
            this.BTNA15 = new System.Windows.Forms.Button();
            this.BTNA14 = new System.Windows.Forms.Button();
            this.BTNA13 = new System.Windows.Forms.Button();
            this.BTNA12 = new System.Windows.Forms.Button();
            this.BTNA11 = new System.Windows.Forms.Button();
            this.BTNA10 = new System.Windows.Forms.Button();
            this.BTNA9 = new System.Windows.Forms.Button();
            this.BTNA8 = new System.Windows.Forms.Button();
            this.BTNA7 = new System.Windows.Forms.Button();
            this.BTNA6 = new System.Windows.Forms.Button();
            this.BTNA5 = new System.Windows.Forms.Button();
            this.BTNA4 = new System.Windows.Forms.Button();
            this.BTNA3 = new System.Windows.Forms.Button();
            this.BTNA2 = new System.Windows.Forms.Button();
            this.BTNA1 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.TBnombre = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.BTNno = new System.Windows.Forms.Button();
            this.BTNsi = new System.Windows.Forms.Button();
            this.LBLaccion = new System.Windows.Forms.Label();
            this.TBestadoasiento = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.TBnumeroasiento = new System.Windows.Forms.TextBox();
            this.button153 = new System.Windows.Forms.Button();
            this.BTNlimpia = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.BTNJ15);
            this.panel1.Controls.Add(this.BTNJ14);
            this.panel1.Controls.Add(this.BTNJ13);
            this.panel1.Controls.Add(this.BTNJ12);
            this.panel1.Controls.Add(this.BTNJ11);
            this.panel1.Controls.Add(this.BTNJ10);
            this.panel1.Controls.Add(this.BTNJ9);
            this.panel1.Controls.Add(this.BTNJ8);
            this.panel1.Controls.Add(this.BTNJ7);
            this.panel1.Controls.Add(this.BTNJ6);
            this.panel1.Controls.Add(this.BTNJ5);
            this.panel1.Controls.Add(this.BTNJ4);
            this.panel1.Controls.Add(this.BTNJ3);
            this.panel1.Controls.Add(this.BTNJ2);
            this.panel1.Controls.Add(this.BTNJ1);
            this.panel1.Controls.Add(this.BTNI15);
            this.panel1.Controls.Add(this.BTNI14);
            this.panel1.Controls.Add(this.BTNI13);
            this.panel1.Controls.Add(this.BTNI12);
            this.panel1.Controls.Add(this.BTNI11);
            this.panel1.Controls.Add(this.BTNI10);
            this.panel1.Controls.Add(this.BTNI9);
            this.panel1.Controls.Add(this.BTNI8);
            this.panel1.Controls.Add(this.BTNI7);
            this.panel1.Controls.Add(this.BTNI6);
            this.panel1.Controls.Add(this.BTNI5);
            this.panel1.Controls.Add(this.BTNI4);
            this.panel1.Controls.Add(this.BTNI3);
            this.panel1.Controls.Add(this.BTNI2);
            this.panel1.Controls.Add(this.BTNI1);
            this.panel1.Controls.Add(this.BTNH15);
            this.panel1.Controls.Add(this.BTNH14);
            this.panel1.Controls.Add(this.BTNH13);
            this.panel1.Controls.Add(this.BTNH12);
            this.panel1.Controls.Add(this.BTNH11);
            this.panel1.Controls.Add(this.BTNH10);
            this.panel1.Controls.Add(this.BTNH9);
            this.panel1.Controls.Add(this.BTNH8);
            this.panel1.Controls.Add(this.BTNH7);
            this.panel1.Controls.Add(this.BTNH6);
            this.panel1.Controls.Add(this.BTNH5);
            this.panel1.Controls.Add(this.BTNH4);
            this.panel1.Controls.Add(this.BTNH3);
            this.panel1.Controls.Add(this.BTNH2);
            this.panel1.Controls.Add(this.BTNH1);
            this.panel1.Controls.Add(this.BTNG15);
            this.panel1.Controls.Add(this.BTNG14);
            this.panel1.Controls.Add(this.BTNG13);
            this.panel1.Controls.Add(this.BTNG12);
            this.panel1.Controls.Add(this.BTNG11);
            this.panel1.Controls.Add(this.BTNG10);
            this.panel1.Controls.Add(this.BTNG9);
            this.panel1.Controls.Add(this.BTNG8);
            this.panel1.Controls.Add(this.BTNG7);
            this.panel1.Controls.Add(this.BTNG6);
            this.panel1.Controls.Add(this.BTNG5);
            this.panel1.Controls.Add(this.BTNG4);
            this.panel1.Controls.Add(this.BTNG3);
            this.panel1.Controls.Add(this.BTNG2);
            this.panel1.Controls.Add(this.BTNG1);
            this.panel1.Controls.Add(this.BTNF15);
            this.panel1.Controls.Add(this.BTNF14);
            this.panel1.Controls.Add(this.BTNF13);
            this.panel1.Controls.Add(this.BTNF12);
            this.panel1.Controls.Add(this.BTNF11);
            this.panel1.Controls.Add(this.BTNF10);
            this.panel1.Controls.Add(this.BTNF9);
            this.panel1.Controls.Add(this.BTNF8);
            this.panel1.Controls.Add(this.BTNF7);
            this.panel1.Controls.Add(this.BTNF6);
            this.panel1.Controls.Add(this.BTNF5);
            this.panel1.Controls.Add(this.BTNF4);
            this.panel1.Controls.Add(this.BTNF3);
            this.panel1.Controls.Add(this.BTNF2);
            this.panel1.Controls.Add(this.BTNF1);
            this.panel1.Controls.Add(this.BTNE15);
            this.panel1.Controls.Add(this.BTNE14);
            this.panel1.Controls.Add(this.BTNE13);
            this.panel1.Controls.Add(this.BTNE12);
            this.panel1.Controls.Add(this.BTNE11);
            this.panel1.Controls.Add(this.BTNE10);
            this.panel1.Controls.Add(this.BTNE9);
            this.panel1.Controls.Add(this.BTNE8);
            this.panel1.Controls.Add(this.BTNE7);
            this.panel1.Controls.Add(this.BTNE6);
            this.panel1.Controls.Add(this.BTNE5);
            this.panel1.Controls.Add(this.BTNE4);
            this.panel1.Controls.Add(this.BTNE3);
            this.panel1.Controls.Add(this.BTNE2);
            this.panel1.Controls.Add(this.BTNE1);
            this.panel1.Controls.Add(this.BTND15);
            this.panel1.Controls.Add(this.BTND14);
            this.panel1.Controls.Add(this.BTND13);
            this.panel1.Controls.Add(this.BTND12);
            this.panel1.Controls.Add(this.BTND11);
            this.panel1.Controls.Add(this.BTND10);
            this.panel1.Controls.Add(this.BTND9);
            this.panel1.Controls.Add(this.BTND8);
            this.panel1.Controls.Add(this.BTND7);
            this.panel1.Controls.Add(this.BTND6);
            this.panel1.Controls.Add(this.BTND5);
            this.panel1.Controls.Add(this.BTND4);
            this.panel1.Controls.Add(this.BTND3);
            this.panel1.Controls.Add(this.BTND2);
            this.panel1.Controls.Add(this.BTND1);
            this.panel1.Controls.Add(this.BTNC15);
            this.panel1.Controls.Add(this.BTNC14);
            this.panel1.Controls.Add(this.BTNC13);
            this.panel1.Controls.Add(this.BTNC12);
            this.panel1.Controls.Add(this.BTNC11);
            this.panel1.Controls.Add(this.BTNC10);
            this.panel1.Controls.Add(this.BTNC9);
            this.panel1.Controls.Add(this.BTNC8);
            this.panel1.Controls.Add(this.BTNC7);
            this.panel1.Controls.Add(this.BTNC6);
            this.panel1.Controls.Add(this.BTNC5);
            this.panel1.Controls.Add(this.BTNC4);
            this.panel1.Controls.Add(this.BTNC3);
            this.panel1.Controls.Add(this.BTNC2);
            this.panel1.Controls.Add(this.BTNC1);
            this.panel1.Controls.Add(this.BTNB15);
            this.panel1.Controls.Add(this.BTNB14);
            this.panel1.Controls.Add(this.BTNB13);
            this.panel1.Controls.Add(this.BTNB12);
            this.panel1.Controls.Add(this.BTNB11);
            this.panel1.Controls.Add(this.BTNB10);
            this.panel1.Controls.Add(this.BTNB9);
            this.panel1.Controls.Add(this.BTNB8);
            this.panel1.Controls.Add(this.BTNB7);
            this.panel1.Controls.Add(this.BTNB6);
            this.panel1.Controls.Add(this.BTNB5);
            this.panel1.Controls.Add(this.BTNB4);
            this.panel1.Controls.Add(this.BTNB3);
            this.panel1.Controls.Add(this.BTNB2);
            this.panel1.Controls.Add(this.BTNB1);
            this.panel1.Controls.Add(this.BTNA15);
            this.panel1.Controls.Add(this.BTNA14);
            this.panel1.Controls.Add(this.BTNA13);
            this.panel1.Controls.Add(this.BTNA12);
            this.panel1.Controls.Add(this.BTNA11);
            this.panel1.Controls.Add(this.BTNA10);
            this.panel1.Controls.Add(this.BTNA9);
            this.panel1.Controls.Add(this.BTNA8);
            this.panel1.Controls.Add(this.BTNA7);
            this.panel1.Controls.Add(this.BTNA6);
            this.panel1.Controls.Add(this.BTNA5);
            this.panel1.Controls.Add(this.BTNA4);
            this.panel1.Controls.Add(this.BTNA3);
            this.panel1.Controls.Add(this.BTNA2);
            this.panel1.Controls.Add(this.BTNA1);
            this.panel1.Location = new System.Drawing.Point(9, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(656, 521);
            this.panel1.TabIndex = 0;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(19, 20);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(311, 20);
            this.label29.TabIndex = 176;
            this.label29.Text = "* Por favor seleccione el asiento a reservar:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProyectoTeatro.Properties.Resources.istockphoto_499309130_612x612;
            this.pictureBox1.Location = new System.Drawing.Point(155, 411);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(361, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 175;
            this.pictureBox1.TabStop = false;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(582, 70);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(27, 20);
            this.label25.TabIndex = 174;
            this.label25.Text = "15";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(543, 70);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(27, 20);
            this.label26.TabIndex = 173;
            this.label26.Text = "14";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(506, 70);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(27, 20);
            this.label23.TabIndex = 172;
            this.label23.Text = "13";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(467, 70);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(27, 20);
            this.label24.TabIndex = 171;
            this.label24.Text = "12";
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(431, 70);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(27, 20);
            this.label22.TabIndex = 170;
            this.label22.Text = "11";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(392, 70);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(27, 20);
            this.label17.TabIndex = 169;
            this.label17.Text = "10";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(358, 70);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(18, 20);
            this.label18.TabIndex = 168;
            this.label18.Text = "9";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(320, 70);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(18, 20);
            this.label19.TabIndex = 167;
            this.label19.Text = "8";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(244, 70);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(18, 20);
            this.label20.TabIndex = 165;
            this.label20.Text = "6";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(282, 70);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(18, 20);
            this.label21.TabIndex = 166;
            this.label21.Text = "7";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(206, 70);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(18, 20);
            this.label16.TabIndex = 164;
            this.label16.Text = "5";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(168, 70);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 20);
            this.label15.TabIndex = 163;
            this.label15.Text = "4";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(130, 70);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(18, 20);
            this.label14.TabIndex = 162;
            this.label14.Text = "3";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(54, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 20);
            this.label12.TabIndex = 160;
            this.label12.Text = "1";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(92, 70);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 20);
            this.label13.TabIndex = 161;
            this.label13.Text = "2";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 380);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 20);
            this.label7.TabIndex = 159;
            this.label7.Text = "J";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 349);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 20);
            this.label8.TabIndex = 158;
            this.label8.Text = "I";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 318);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 20);
            this.label9.TabIndex = 157;
            this.label9.Text = "H";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 287);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 20);
            this.label10.TabIndex = 156;
            this.label10.Text = "G";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 256);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(19, 20);
            this.label11.TabIndex = 155;
            this.label11.Text = "F";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 228);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 20);
            this.label6.TabIndex = 154;
            this.label6.Text = "E";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 20);
            this.label5.TabIndex = 153;
            this.label5.Text = "D";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 20);
            this.label4.TabIndex = 152;
            this.label4.Text = "C";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 20);
            this.label3.TabIndex = 151;
            this.label3.Text = "B";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 20);
            this.label2.TabIndex = 150;
            this.label2.Text = "A";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // BTNJ15
            // 
            this.BTNJ15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ15.Location = new System.Drawing.Point(580, 378);
            this.BTNJ15.Name = "BTNJ15";
            this.BTNJ15.Size = new System.Drawing.Size(32, 25);
            this.BTNJ15.TabIndex = 149;
            this.BTNJ15.Text = " ";
            this.BTNJ15.UseVisualStyleBackColor = false;
            this.BTNJ15.Click += new System.EventHandler(this.BTNJ15_Click);
            // 
            // BTNJ14
            // 
            this.BTNJ14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ14.Location = new System.Drawing.Point(542, 378);
            this.BTNJ14.Name = "BTNJ14";
            this.BTNJ14.Size = new System.Drawing.Size(32, 25);
            this.BTNJ14.TabIndex = 148;
            this.BTNJ14.Text = " ";
            this.BTNJ14.UseVisualStyleBackColor = false;
            this.BTNJ14.Click += new System.EventHandler(this.BTNJ14_Click);
            // 
            // BTNJ13
            // 
            this.BTNJ13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ13.Location = new System.Drawing.Point(504, 378);
            this.BTNJ13.Name = "BTNJ13";
            this.BTNJ13.Size = new System.Drawing.Size(32, 25);
            this.BTNJ13.TabIndex = 147;
            this.BTNJ13.Text = " ";
            this.BTNJ13.UseVisualStyleBackColor = false;
            this.BTNJ13.Click += new System.EventHandler(this.BTNJ13_Click);
            // 
            // BTNJ12
            // 
            this.BTNJ12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ12.Location = new System.Drawing.Point(467, 378);
            this.BTNJ12.Name = "BTNJ12";
            this.BTNJ12.Size = new System.Drawing.Size(32, 25);
            this.BTNJ12.TabIndex = 146;
            this.BTNJ12.Text = " ";
            this.BTNJ12.UseVisualStyleBackColor = false;
            this.BTNJ12.Click += new System.EventHandler(this.BTNJ12_Click);
            // 
            // BTNJ11
            // 
            this.BTNJ11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ11.Location = new System.Drawing.Point(429, 378);
            this.BTNJ11.Name = "BTNJ11";
            this.BTNJ11.Size = new System.Drawing.Size(32, 25);
            this.BTNJ11.TabIndex = 145;
            this.BTNJ11.Text = " ";
            this.BTNJ11.UseVisualStyleBackColor = false;
            this.BTNJ11.Click += new System.EventHandler(this.BTNJ11_Click);
            // 
            // BTNJ10
            // 
            this.BTNJ10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ10.Location = new System.Drawing.Point(391, 378);
            this.BTNJ10.Name = "BTNJ10";
            this.BTNJ10.Size = new System.Drawing.Size(32, 25);
            this.BTNJ10.TabIndex = 144;
            this.BTNJ10.Text = " ";
            this.BTNJ10.UseVisualStyleBackColor = false;
            this.BTNJ10.Click += new System.EventHandler(this.BTNJ10_Click);
            // 
            // BTNJ9
            // 
            this.BTNJ9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ9.Location = new System.Drawing.Point(353, 378);
            this.BTNJ9.Name = "BTNJ9";
            this.BTNJ9.Size = new System.Drawing.Size(32, 25);
            this.BTNJ9.TabIndex = 143;
            this.BTNJ9.Text = " ";
            this.BTNJ9.UseVisualStyleBackColor = false;
            this.BTNJ9.Click += new System.EventHandler(this.BTNJ9_Click);
            // 
            // BTNJ8
            // 
            this.BTNJ8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ8.Location = new System.Drawing.Point(315, 378);
            this.BTNJ8.Name = "BTNJ8";
            this.BTNJ8.Size = new System.Drawing.Size(32, 25);
            this.BTNJ8.TabIndex = 142;
            this.BTNJ8.Text = " ";
            this.BTNJ8.UseVisualStyleBackColor = false;
            this.BTNJ8.Click += new System.EventHandler(this.BTNJ8_Click);
            // 
            // BTNJ7
            // 
            this.BTNJ7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ7.Location = new System.Drawing.Point(277, 378);
            this.BTNJ7.Name = "BTNJ7";
            this.BTNJ7.Size = new System.Drawing.Size(32, 25);
            this.BTNJ7.TabIndex = 141;
            this.BTNJ7.Text = " ";
            this.BTNJ7.UseVisualStyleBackColor = false;
            this.BTNJ7.Click += new System.EventHandler(this.BTNJ7_Click);
            // 
            // BTNJ6
            // 
            this.BTNJ6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ6.Location = new System.Drawing.Point(239, 378);
            this.BTNJ6.Name = "BTNJ6";
            this.BTNJ6.Size = new System.Drawing.Size(32, 25);
            this.BTNJ6.TabIndex = 140;
            this.BTNJ6.Text = " ";
            this.BTNJ6.UseVisualStyleBackColor = false;
            this.BTNJ6.Click += new System.EventHandler(this.BTNJ6_Click);
            // 
            // BTNJ5
            // 
            this.BTNJ5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ5.Location = new System.Drawing.Point(201, 378);
            this.BTNJ5.Name = "BTNJ5";
            this.BTNJ5.Size = new System.Drawing.Size(32, 25);
            this.BTNJ5.TabIndex = 139;
            this.BTNJ5.Text = " ";
            this.BTNJ5.UseVisualStyleBackColor = false;
            this.BTNJ5.Click += new System.EventHandler(this.BTNJ5_Click);
            // 
            // BTNJ4
            // 
            this.BTNJ4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ4.Location = new System.Drawing.Point(163, 378);
            this.BTNJ4.Name = "BTNJ4";
            this.BTNJ4.Size = new System.Drawing.Size(32, 25);
            this.BTNJ4.TabIndex = 138;
            this.BTNJ4.Text = " ";
            this.BTNJ4.UseVisualStyleBackColor = false;
            this.BTNJ4.Click += new System.EventHandler(this.BTNJ4_Click);
            // 
            // BTNJ3
            // 
            this.BTNJ3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ3.Location = new System.Drawing.Point(125, 378);
            this.BTNJ3.Name = "BTNJ3";
            this.BTNJ3.Size = new System.Drawing.Size(32, 25);
            this.BTNJ3.TabIndex = 137;
            this.BTNJ3.Text = " ";
            this.BTNJ3.UseVisualStyleBackColor = false;
            this.BTNJ3.Click += new System.EventHandler(this.BTNJ3_Click);
            // 
            // BTNJ2
            // 
            this.BTNJ2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ2.Location = new System.Drawing.Point(87, 378);
            this.BTNJ2.Name = "BTNJ2";
            this.BTNJ2.Size = new System.Drawing.Size(32, 25);
            this.BTNJ2.TabIndex = 136;
            this.BTNJ2.Text = " ";
            this.BTNJ2.UseVisualStyleBackColor = false;
            this.BTNJ2.Click += new System.EventHandler(this.BTNJ2_Click);
            // 
            // BTNJ1
            // 
            this.BTNJ1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNJ1.Location = new System.Drawing.Point(49, 378);
            this.BTNJ1.Name = "BTNJ1";
            this.BTNJ1.Size = new System.Drawing.Size(32, 25);
            this.BTNJ1.TabIndex = 135;
            this.BTNJ1.Text = " ";
            this.BTNJ1.UseVisualStyleBackColor = false;
            this.BTNJ1.Click += new System.EventHandler(this.BTNJ1_Click);
            // 
            // BTNI15
            // 
            this.BTNI15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI15.Location = new System.Drawing.Point(580, 347);
            this.BTNI15.Name = "BTNI15";
            this.BTNI15.Size = new System.Drawing.Size(32, 25);
            this.BTNI15.TabIndex = 134;
            this.BTNI15.Text = " ";
            this.BTNI15.UseVisualStyleBackColor = false;
            this.BTNI15.Click += new System.EventHandler(this.BTNI15_Click);
            // 
            // BTNI14
            // 
            this.BTNI14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI14.Location = new System.Drawing.Point(542, 347);
            this.BTNI14.Name = "BTNI14";
            this.BTNI14.Size = new System.Drawing.Size(32, 25);
            this.BTNI14.TabIndex = 133;
            this.BTNI14.Text = " ";
            this.BTNI14.UseVisualStyleBackColor = false;
            this.BTNI14.Click += new System.EventHandler(this.BTNI14_Click);
            // 
            // BTNI13
            // 
            this.BTNI13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI13.Location = new System.Drawing.Point(504, 347);
            this.BTNI13.Name = "BTNI13";
            this.BTNI13.Size = new System.Drawing.Size(32, 25);
            this.BTNI13.TabIndex = 132;
            this.BTNI13.Text = " ";
            this.BTNI13.UseVisualStyleBackColor = false;
            this.BTNI13.Click += new System.EventHandler(this.BTNI13_Click);
            // 
            // BTNI12
            // 
            this.BTNI12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI12.Location = new System.Drawing.Point(467, 347);
            this.BTNI12.Name = "BTNI12";
            this.BTNI12.Size = new System.Drawing.Size(32, 25);
            this.BTNI12.TabIndex = 131;
            this.BTNI12.Text = " ";
            this.BTNI12.UseVisualStyleBackColor = false;
            this.BTNI12.Click += new System.EventHandler(this.BTNI12_Click);
            // 
            // BTNI11
            // 
            this.BTNI11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI11.Location = new System.Drawing.Point(429, 347);
            this.BTNI11.Name = "BTNI11";
            this.BTNI11.Size = new System.Drawing.Size(32, 25);
            this.BTNI11.TabIndex = 130;
            this.BTNI11.Text = " ";
            this.BTNI11.UseVisualStyleBackColor = false;
            this.BTNI11.Click += new System.EventHandler(this.BTNI11_Click);
            // 
            // BTNI10
            // 
            this.BTNI10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI10.Location = new System.Drawing.Point(391, 347);
            this.BTNI10.Name = "BTNI10";
            this.BTNI10.Size = new System.Drawing.Size(32, 25);
            this.BTNI10.TabIndex = 129;
            this.BTNI10.Text = " ";
            this.BTNI10.UseVisualStyleBackColor = false;
            this.BTNI10.Click += new System.EventHandler(this.BTNI10_Click);
            // 
            // BTNI9
            // 
            this.BTNI9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI9.Location = new System.Drawing.Point(353, 347);
            this.BTNI9.Name = "BTNI9";
            this.BTNI9.Size = new System.Drawing.Size(32, 25);
            this.BTNI9.TabIndex = 128;
            this.BTNI9.Text = " ";
            this.BTNI9.UseVisualStyleBackColor = false;
            this.BTNI9.Click += new System.EventHandler(this.BTNI9_Click);
            // 
            // BTNI8
            // 
            this.BTNI8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI8.Location = new System.Drawing.Point(315, 347);
            this.BTNI8.Name = "BTNI8";
            this.BTNI8.Size = new System.Drawing.Size(32, 25);
            this.BTNI8.TabIndex = 127;
            this.BTNI8.Text = " ";
            this.BTNI8.UseVisualStyleBackColor = false;
            this.BTNI8.Click += new System.EventHandler(this.BTNI8_Click);
            // 
            // BTNI7
            // 
            this.BTNI7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI7.Location = new System.Drawing.Point(277, 347);
            this.BTNI7.Name = "BTNI7";
            this.BTNI7.Size = new System.Drawing.Size(32, 25);
            this.BTNI7.TabIndex = 126;
            this.BTNI7.Text = " ";
            this.BTNI7.UseVisualStyleBackColor = false;
            this.BTNI7.Click += new System.EventHandler(this.BTNI7_Click);
            // 
            // BTNI6
            // 
            this.BTNI6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI6.Location = new System.Drawing.Point(239, 347);
            this.BTNI6.Name = "BTNI6";
            this.BTNI6.Size = new System.Drawing.Size(32, 25);
            this.BTNI6.TabIndex = 125;
            this.BTNI6.Text = " ";
            this.BTNI6.UseVisualStyleBackColor = false;
            this.BTNI6.Click += new System.EventHandler(this.BTNI6_Click);
            // 
            // BTNI5
            // 
            this.BTNI5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI5.Location = new System.Drawing.Point(201, 347);
            this.BTNI5.Name = "BTNI5";
            this.BTNI5.Size = new System.Drawing.Size(32, 25);
            this.BTNI5.TabIndex = 124;
            this.BTNI5.Text = " ";
            this.BTNI5.UseVisualStyleBackColor = false;
            this.BTNI5.Click += new System.EventHandler(this.BTNI5_Click);
            // 
            // BTNI4
            // 
            this.BTNI4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI4.Location = new System.Drawing.Point(163, 347);
            this.BTNI4.Name = "BTNI4";
            this.BTNI4.Size = new System.Drawing.Size(32, 25);
            this.BTNI4.TabIndex = 123;
            this.BTNI4.Text = " ";
            this.BTNI4.UseVisualStyleBackColor = false;
            this.BTNI4.Click += new System.EventHandler(this.BTNI4_Click);
            // 
            // BTNI3
            // 
            this.BTNI3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI3.Location = new System.Drawing.Point(125, 347);
            this.BTNI3.Name = "BTNI3";
            this.BTNI3.Size = new System.Drawing.Size(32, 25);
            this.BTNI3.TabIndex = 122;
            this.BTNI3.Text = " ";
            this.BTNI3.UseVisualStyleBackColor = false;
            this.BTNI3.Click += new System.EventHandler(this.BTNI3_Click);
            // 
            // BTNI2
            // 
            this.BTNI2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI2.Location = new System.Drawing.Point(87, 347);
            this.BTNI2.Name = "BTNI2";
            this.BTNI2.Size = new System.Drawing.Size(32, 25);
            this.BTNI2.TabIndex = 121;
            this.BTNI2.Text = " ";
            this.BTNI2.UseVisualStyleBackColor = false;
            this.BTNI2.Click += new System.EventHandler(this.BTNI2_Click);
            // 
            // BTNI1
            // 
            this.BTNI1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNI1.Location = new System.Drawing.Point(49, 347);
            this.BTNI1.Name = "BTNI1";
            this.BTNI1.Size = new System.Drawing.Size(32, 25);
            this.BTNI1.TabIndex = 120;
            this.BTNI1.Text = " ";
            this.BTNI1.UseVisualStyleBackColor = false;
            this.BTNI1.Click += new System.EventHandler(this.BTNI1_Click);
            // 
            // BTNH15
            // 
            this.BTNH15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH15.Location = new System.Drawing.Point(580, 316);
            this.BTNH15.Name = "BTNH15";
            this.BTNH15.Size = new System.Drawing.Size(32, 25);
            this.BTNH15.TabIndex = 119;
            this.BTNH15.Text = " ";
            this.BTNH15.UseVisualStyleBackColor = false;
            this.BTNH15.Click += new System.EventHandler(this.BTNH15_Click);
            // 
            // BTNH14
            // 
            this.BTNH14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH14.Location = new System.Drawing.Point(542, 316);
            this.BTNH14.Name = "BTNH14";
            this.BTNH14.Size = new System.Drawing.Size(32, 25);
            this.BTNH14.TabIndex = 118;
            this.BTNH14.Text = " ";
            this.BTNH14.UseVisualStyleBackColor = false;
            this.BTNH14.Click += new System.EventHandler(this.BTNH14_Click);
            // 
            // BTNH13
            // 
            this.BTNH13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH13.Location = new System.Drawing.Point(504, 316);
            this.BTNH13.Name = "BTNH13";
            this.BTNH13.Size = new System.Drawing.Size(32, 25);
            this.BTNH13.TabIndex = 117;
            this.BTNH13.Text = " ";
            this.BTNH13.UseVisualStyleBackColor = false;
            this.BTNH13.Click += new System.EventHandler(this.BTNH13_Click);
            // 
            // BTNH12
            // 
            this.BTNH12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH12.Location = new System.Drawing.Point(467, 316);
            this.BTNH12.Name = "BTNH12";
            this.BTNH12.Size = new System.Drawing.Size(32, 25);
            this.BTNH12.TabIndex = 116;
            this.BTNH12.Text = " ";
            this.BTNH12.UseVisualStyleBackColor = false;
            this.BTNH12.Click += new System.EventHandler(this.BTNH12_Click);
            // 
            // BTNH11
            // 
            this.BTNH11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH11.Location = new System.Drawing.Point(429, 316);
            this.BTNH11.Name = "BTNH11";
            this.BTNH11.Size = new System.Drawing.Size(32, 25);
            this.BTNH11.TabIndex = 115;
            this.BTNH11.Text = " ";
            this.BTNH11.UseVisualStyleBackColor = false;
            this.BTNH11.Click += new System.EventHandler(this.BTNH11_Click);
            // 
            // BTNH10
            // 
            this.BTNH10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH10.Location = new System.Drawing.Point(391, 316);
            this.BTNH10.Name = "BTNH10";
            this.BTNH10.Size = new System.Drawing.Size(32, 25);
            this.BTNH10.TabIndex = 114;
            this.BTNH10.Text = " ";
            this.BTNH10.UseVisualStyleBackColor = false;
            this.BTNH10.Click += new System.EventHandler(this.BTNH10_Click);
            // 
            // BTNH9
            // 
            this.BTNH9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH9.Location = new System.Drawing.Point(353, 316);
            this.BTNH9.Name = "BTNH9";
            this.BTNH9.Size = new System.Drawing.Size(32, 25);
            this.BTNH9.TabIndex = 113;
            this.BTNH9.Text = " ";
            this.BTNH9.UseVisualStyleBackColor = false;
            this.BTNH9.Click += new System.EventHandler(this.BTNH9_Click);
            // 
            // BTNH8
            // 
            this.BTNH8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH8.Location = new System.Drawing.Point(315, 316);
            this.BTNH8.Name = "BTNH8";
            this.BTNH8.Size = new System.Drawing.Size(32, 25);
            this.BTNH8.TabIndex = 112;
            this.BTNH8.Text = " ";
            this.BTNH8.UseVisualStyleBackColor = false;
            this.BTNH8.Click += new System.EventHandler(this.BTNH8_Click);
            // 
            // BTNH7
            // 
            this.BTNH7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH7.Location = new System.Drawing.Point(277, 316);
            this.BTNH7.Name = "BTNH7";
            this.BTNH7.Size = new System.Drawing.Size(32, 25);
            this.BTNH7.TabIndex = 111;
            this.BTNH7.Text = " ";
            this.BTNH7.UseVisualStyleBackColor = false;
            this.BTNH7.Click += new System.EventHandler(this.BTNH7_Click);
            // 
            // BTNH6
            // 
            this.BTNH6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH6.Location = new System.Drawing.Point(239, 316);
            this.BTNH6.Name = "BTNH6";
            this.BTNH6.Size = new System.Drawing.Size(32, 25);
            this.BTNH6.TabIndex = 110;
            this.BTNH6.Text = " ";
            this.BTNH6.UseVisualStyleBackColor = false;
            this.BTNH6.Click += new System.EventHandler(this.BTNH6_Click);
            // 
            // BTNH5
            // 
            this.BTNH5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH5.Location = new System.Drawing.Point(201, 316);
            this.BTNH5.Name = "BTNH5";
            this.BTNH5.Size = new System.Drawing.Size(32, 25);
            this.BTNH5.TabIndex = 109;
            this.BTNH5.Text = " ";
            this.BTNH5.UseVisualStyleBackColor = false;
            this.BTNH5.Click += new System.EventHandler(this.BTNH5_Click);
            // 
            // BTNH4
            // 
            this.BTNH4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH4.Location = new System.Drawing.Point(163, 316);
            this.BTNH4.Name = "BTNH4";
            this.BTNH4.Size = new System.Drawing.Size(32, 25);
            this.BTNH4.TabIndex = 108;
            this.BTNH4.Text = " ";
            this.BTNH4.UseVisualStyleBackColor = false;
            this.BTNH4.Click += new System.EventHandler(this.BTNH4_Click);
            // 
            // BTNH3
            // 
            this.BTNH3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH3.Location = new System.Drawing.Point(125, 316);
            this.BTNH3.Name = "BTNH3";
            this.BTNH3.Size = new System.Drawing.Size(32, 25);
            this.BTNH3.TabIndex = 107;
            this.BTNH3.Text = " ";
            this.BTNH3.UseVisualStyleBackColor = false;
            this.BTNH3.Click += new System.EventHandler(this.BTNH3_Click);
            // 
            // BTNH2
            // 
            this.BTNH2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH2.Location = new System.Drawing.Point(87, 316);
            this.BTNH2.Name = "BTNH2";
            this.BTNH2.Size = new System.Drawing.Size(32, 25);
            this.BTNH2.TabIndex = 106;
            this.BTNH2.Text = " ";
            this.BTNH2.UseVisualStyleBackColor = false;
            this.BTNH2.Click += new System.EventHandler(this.BTNH2_Click);
            // 
            // BTNH1
            // 
            this.BTNH1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNH1.Location = new System.Drawing.Point(49, 316);
            this.BTNH1.Name = "BTNH1";
            this.BTNH1.Size = new System.Drawing.Size(32, 25);
            this.BTNH1.TabIndex = 105;
            this.BTNH1.Text = " ";
            this.BTNH1.UseVisualStyleBackColor = false;
            this.BTNH1.Click += new System.EventHandler(this.BTNH1_Click);
            // 
            // BTNG15
            // 
            this.BTNG15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG15.Location = new System.Drawing.Point(580, 285);
            this.BTNG15.Name = "BTNG15";
            this.BTNG15.Size = new System.Drawing.Size(32, 25);
            this.BTNG15.TabIndex = 104;
            this.BTNG15.Text = " ";
            this.BTNG15.UseVisualStyleBackColor = false;
            this.BTNG15.Click += new System.EventHandler(this.BTNG15_Click);
            // 
            // BTNG14
            // 
            this.BTNG14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG14.Location = new System.Drawing.Point(542, 285);
            this.BTNG14.Name = "BTNG14";
            this.BTNG14.Size = new System.Drawing.Size(32, 25);
            this.BTNG14.TabIndex = 103;
            this.BTNG14.Text = " ";
            this.BTNG14.UseVisualStyleBackColor = false;
            this.BTNG14.Click += new System.EventHandler(this.BTNG14_Click);
            // 
            // BTNG13
            // 
            this.BTNG13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG13.Location = new System.Drawing.Point(504, 285);
            this.BTNG13.Name = "BTNG13";
            this.BTNG13.Size = new System.Drawing.Size(32, 25);
            this.BTNG13.TabIndex = 102;
            this.BTNG13.Text = " ";
            this.BTNG13.UseVisualStyleBackColor = false;
            this.BTNG13.Click += new System.EventHandler(this.BTNG13_Click);
            // 
            // BTNG12
            // 
            this.BTNG12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG12.Location = new System.Drawing.Point(467, 285);
            this.BTNG12.Name = "BTNG12";
            this.BTNG12.Size = new System.Drawing.Size(32, 25);
            this.BTNG12.TabIndex = 101;
            this.BTNG12.Text = " ";
            this.BTNG12.UseVisualStyleBackColor = false;
            this.BTNG12.Click += new System.EventHandler(this.BTNG12_Click);
            // 
            // BTNG11
            // 
            this.BTNG11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG11.Location = new System.Drawing.Point(429, 285);
            this.BTNG11.Name = "BTNG11";
            this.BTNG11.Size = new System.Drawing.Size(32, 25);
            this.BTNG11.TabIndex = 100;
            this.BTNG11.Text = " ";
            this.BTNG11.UseVisualStyleBackColor = false;
            this.BTNG11.Click += new System.EventHandler(this.BTNG11_Click);
            // 
            // BTNG10
            // 
            this.BTNG10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG10.Location = new System.Drawing.Point(391, 285);
            this.BTNG10.Name = "BTNG10";
            this.BTNG10.Size = new System.Drawing.Size(32, 25);
            this.BTNG10.TabIndex = 99;
            this.BTNG10.Text = " ";
            this.BTNG10.UseVisualStyleBackColor = false;
            this.BTNG10.Click += new System.EventHandler(this.BTNG10_Click);
            // 
            // BTNG9
            // 
            this.BTNG9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG9.Location = new System.Drawing.Point(353, 285);
            this.BTNG9.Name = "BTNG9";
            this.BTNG9.Size = new System.Drawing.Size(32, 25);
            this.BTNG9.TabIndex = 98;
            this.BTNG9.Text = " ";
            this.BTNG9.UseVisualStyleBackColor = false;
            this.BTNG9.Click += new System.EventHandler(this.BTNG9_Click);
            // 
            // BTNG8
            // 
            this.BTNG8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG8.Location = new System.Drawing.Point(315, 285);
            this.BTNG8.Name = "BTNG8";
            this.BTNG8.Size = new System.Drawing.Size(32, 25);
            this.BTNG8.TabIndex = 97;
            this.BTNG8.Text = " ";
            this.BTNG8.UseVisualStyleBackColor = false;
            this.BTNG8.Click += new System.EventHandler(this.BTNG8_Click);
            // 
            // BTNG7
            // 
            this.BTNG7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG7.Location = new System.Drawing.Point(277, 285);
            this.BTNG7.Name = "BTNG7";
            this.BTNG7.Size = new System.Drawing.Size(32, 25);
            this.BTNG7.TabIndex = 96;
            this.BTNG7.Text = " ";
            this.BTNG7.UseVisualStyleBackColor = false;
            this.BTNG7.Click += new System.EventHandler(this.BTNG7_Click);
            // 
            // BTNG6
            // 
            this.BTNG6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG6.Location = new System.Drawing.Point(239, 285);
            this.BTNG6.Name = "BTNG6";
            this.BTNG6.Size = new System.Drawing.Size(32, 25);
            this.BTNG6.TabIndex = 95;
            this.BTNG6.Text = " ";
            this.BTNG6.UseVisualStyleBackColor = false;
            this.BTNG6.Click += new System.EventHandler(this.BTNG6_Click);
            // 
            // BTNG5
            // 
            this.BTNG5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG5.Location = new System.Drawing.Point(201, 285);
            this.BTNG5.Name = "BTNG5";
            this.BTNG5.Size = new System.Drawing.Size(32, 25);
            this.BTNG5.TabIndex = 94;
            this.BTNG5.Text = " ";
            this.BTNG5.UseVisualStyleBackColor = false;
            this.BTNG5.Click += new System.EventHandler(this.BTNG5_Click);
            // 
            // BTNG4
            // 
            this.BTNG4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG4.Location = new System.Drawing.Point(163, 285);
            this.BTNG4.Name = "BTNG4";
            this.BTNG4.Size = new System.Drawing.Size(32, 25);
            this.BTNG4.TabIndex = 93;
            this.BTNG4.Text = " ";
            this.BTNG4.UseVisualStyleBackColor = false;
            this.BTNG4.Click += new System.EventHandler(this.BTNG4_Click);
            // 
            // BTNG3
            // 
            this.BTNG3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG3.Location = new System.Drawing.Point(125, 285);
            this.BTNG3.Name = "BTNG3";
            this.BTNG3.Size = new System.Drawing.Size(32, 25);
            this.BTNG3.TabIndex = 92;
            this.BTNG3.Text = " ";
            this.BTNG3.UseVisualStyleBackColor = false;
            this.BTNG3.Click += new System.EventHandler(this.BTNG3_Click);
            // 
            // BTNG2
            // 
            this.BTNG2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG2.Location = new System.Drawing.Point(87, 285);
            this.BTNG2.Name = "BTNG2";
            this.BTNG2.Size = new System.Drawing.Size(32, 25);
            this.BTNG2.TabIndex = 91;
            this.BTNG2.Text = " ";
            this.BTNG2.UseVisualStyleBackColor = false;
            this.BTNG2.Click += new System.EventHandler(this.BTNG2_Click);
            // 
            // BTNG1
            // 
            this.BTNG1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNG1.Location = new System.Drawing.Point(49, 285);
            this.BTNG1.Name = "BTNG1";
            this.BTNG1.Size = new System.Drawing.Size(32, 25);
            this.BTNG1.TabIndex = 90;
            this.BTNG1.Text = " ";
            this.BTNG1.UseVisualStyleBackColor = false;
            this.BTNG1.Click += new System.EventHandler(this.BTNG1_Click);
            // 
            // BTNF15
            // 
            this.BTNF15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF15.Location = new System.Drawing.Point(580, 254);
            this.BTNF15.Name = "BTNF15";
            this.BTNF15.Size = new System.Drawing.Size(32, 25);
            this.BTNF15.TabIndex = 89;
            this.BTNF15.Text = " ";
            this.BTNF15.UseVisualStyleBackColor = false;
            this.BTNF15.Click += new System.EventHandler(this.BTNF15_Click);
            // 
            // BTNF14
            // 
            this.BTNF14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF14.Location = new System.Drawing.Point(542, 254);
            this.BTNF14.Name = "BTNF14";
            this.BTNF14.Size = new System.Drawing.Size(32, 25);
            this.BTNF14.TabIndex = 88;
            this.BTNF14.Text = " ";
            this.BTNF14.UseVisualStyleBackColor = false;
            this.BTNF14.Click += new System.EventHandler(this.BTNF14_Click);
            // 
            // BTNF13
            // 
            this.BTNF13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF13.Location = new System.Drawing.Point(504, 254);
            this.BTNF13.Name = "BTNF13";
            this.BTNF13.Size = new System.Drawing.Size(32, 25);
            this.BTNF13.TabIndex = 87;
            this.BTNF13.Text = " ";
            this.BTNF13.UseVisualStyleBackColor = false;
            this.BTNF13.Click += new System.EventHandler(this.BTNF13_Click);
            // 
            // BTNF12
            // 
            this.BTNF12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF12.Location = new System.Drawing.Point(467, 254);
            this.BTNF12.Name = "BTNF12";
            this.BTNF12.Size = new System.Drawing.Size(32, 25);
            this.BTNF12.TabIndex = 86;
            this.BTNF12.Text = " ";
            this.BTNF12.UseVisualStyleBackColor = false;
            this.BTNF12.Click += new System.EventHandler(this.BTNF12_Click);
            // 
            // BTNF11
            // 
            this.BTNF11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF11.Location = new System.Drawing.Point(429, 254);
            this.BTNF11.Name = "BTNF11";
            this.BTNF11.Size = new System.Drawing.Size(32, 25);
            this.BTNF11.TabIndex = 85;
            this.BTNF11.Text = " ";
            this.BTNF11.UseVisualStyleBackColor = false;
            this.BTNF11.Click += new System.EventHandler(this.BTNF11_Click);
            // 
            // BTNF10
            // 
            this.BTNF10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF10.Location = new System.Drawing.Point(391, 254);
            this.BTNF10.Name = "BTNF10";
            this.BTNF10.Size = new System.Drawing.Size(32, 25);
            this.BTNF10.TabIndex = 84;
            this.BTNF10.Text = " ";
            this.BTNF10.UseVisualStyleBackColor = false;
            this.BTNF10.Click += new System.EventHandler(this.BTNF10_Click);
            // 
            // BTNF9
            // 
            this.BTNF9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF9.Location = new System.Drawing.Point(353, 254);
            this.BTNF9.Name = "BTNF9";
            this.BTNF9.Size = new System.Drawing.Size(32, 25);
            this.BTNF9.TabIndex = 83;
            this.BTNF9.Text = " ";
            this.BTNF9.UseVisualStyleBackColor = false;
            this.BTNF9.Click += new System.EventHandler(this.BTNF9_Click);
            // 
            // BTNF8
            // 
            this.BTNF8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF8.Location = new System.Drawing.Point(315, 254);
            this.BTNF8.Name = "BTNF8";
            this.BTNF8.Size = new System.Drawing.Size(32, 25);
            this.BTNF8.TabIndex = 82;
            this.BTNF8.Text = " ";
            this.BTNF8.UseVisualStyleBackColor = false;
            this.BTNF8.Click += new System.EventHandler(this.BTNF8_Click);
            // 
            // BTNF7
            // 
            this.BTNF7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF7.Location = new System.Drawing.Point(277, 254);
            this.BTNF7.Name = "BTNF7";
            this.BTNF7.Size = new System.Drawing.Size(32, 25);
            this.BTNF7.TabIndex = 81;
            this.BTNF7.Text = " ";
            this.BTNF7.UseVisualStyleBackColor = false;
            this.BTNF7.Click += new System.EventHandler(this.BTNF7_Click);
            // 
            // BTNF6
            // 
            this.BTNF6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF6.Location = new System.Drawing.Point(239, 254);
            this.BTNF6.Name = "BTNF6";
            this.BTNF6.Size = new System.Drawing.Size(32, 25);
            this.BTNF6.TabIndex = 80;
            this.BTNF6.Text = " ";
            this.BTNF6.UseVisualStyleBackColor = false;
            this.BTNF6.Click += new System.EventHandler(this.BTNF6_Click);
            // 
            // BTNF5
            // 
            this.BTNF5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF5.Location = new System.Drawing.Point(201, 254);
            this.BTNF5.Name = "BTNF5";
            this.BTNF5.Size = new System.Drawing.Size(32, 25);
            this.BTNF5.TabIndex = 79;
            this.BTNF5.Text = " ";
            this.BTNF5.UseVisualStyleBackColor = false;
            this.BTNF5.Click += new System.EventHandler(this.BTNF5_Click);
            // 
            // BTNF4
            // 
            this.BTNF4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF4.Location = new System.Drawing.Point(163, 254);
            this.BTNF4.Name = "BTNF4";
            this.BTNF4.Size = new System.Drawing.Size(32, 25);
            this.BTNF4.TabIndex = 78;
            this.BTNF4.Text = " ";
            this.BTNF4.UseVisualStyleBackColor = false;
            this.BTNF4.Click += new System.EventHandler(this.BTNF4_Click);
            // 
            // BTNF3
            // 
            this.BTNF3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF3.Location = new System.Drawing.Point(125, 254);
            this.BTNF3.Name = "BTNF3";
            this.BTNF3.Size = new System.Drawing.Size(32, 25);
            this.BTNF3.TabIndex = 77;
            this.BTNF3.Text = " ";
            this.BTNF3.UseVisualStyleBackColor = false;
            this.BTNF3.Click += new System.EventHandler(this.BTNF3_Click);
            // 
            // BTNF2
            // 
            this.BTNF2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF2.Location = new System.Drawing.Point(87, 254);
            this.BTNF2.Name = "BTNF2";
            this.BTNF2.Size = new System.Drawing.Size(32, 25);
            this.BTNF2.TabIndex = 76;
            this.BTNF2.Text = " ";
            this.BTNF2.UseVisualStyleBackColor = false;
            this.BTNF2.Click += new System.EventHandler(this.BTNF2_Click);
            // 
            // BTNF1
            // 
            this.BTNF1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNF1.Location = new System.Drawing.Point(49, 254);
            this.BTNF1.Name = "BTNF1";
            this.BTNF1.Size = new System.Drawing.Size(32, 25);
            this.BTNF1.TabIndex = 75;
            this.BTNF1.Text = " ";
            this.BTNF1.UseVisualStyleBackColor = false;
            this.BTNF1.Click += new System.EventHandler(this.BTNF1_Click);
            // 
            // BTNE15
            // 
            this.BTNE15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE15.Location = new System.Drawing.Point(580, 223);
            this.BTNE15.Name = "BTNE15";
            this.BTNE15.Size = new System.Drawing.Size(32, 25);
            this.BTNE15.TabIndex = 74;
            this.BTNE15.Text = " ";
            this.BTNE15.UseVisualStyleBackColor = false;
            this.BTNE15.Click += new System.EventHandler(this.BTNE15_Click);
            // 
            // BTNE14
            // 
            this.BTNE14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE14.Location = new System.Drawing.Point(542, 223);
            this.BTNE14.Name = "BTNE14";
            this.BTNE14.Size = new System.Drawing.Size(32, 25);
            this.BTNE14.TabIndex = 73;
            this.BTNE14.Text = " ";
            this.BTNE14.UseVisualStyleBackColor = false;
            this.BTNE14.Click += new System.EventHandler(this.BTNE14_Click);
            // 
            // BTNE13
            // 
            this.BTNE13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE13.Location = new System.Drawing.Point(504, 223);
            this.BTNE13.Name = "BTNE13";
            this.BTNE13.Size = new System.Drawing.Size(32, 25);
            this.BTNE13.TabIndex = 72;
            this.BTNE13.Text = " ";
            this.BTNE13.UseVisualStyleBackColor = false;
            this.BTNE13.Click += new System.EventHandler(this.BTNE13_Click);
            // 
            // BTNE12
            // 
            this.BTNE12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE12.Location = new System.Drawing.Point(467, 223);
            this.BTNE12.Name = "BTNE12";
            this.BTNE12.Size = new System.Drawing.Size(32, 25);
            this.BTNE12.TabIndex = 71;
            this.BTNE12.Text = " ";
            this.BTNE12.UseVisualStyleBackColor = false;
            this.BTNE12.Click += new System.EventHandler(this.BTNE12_Click);
            // 
            // BTNE11
            // 
            this.BTNE11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE11.Location = new System.Drawing.Point(429, 223);
            this.BTNE11.Name = "BTNE11";
            this.BTNE11.Size = new System.Drawing.Size(32, 25);
            this.BTNE11.TabIndex = 70;
            this.BTNE11.Text = " ";
            this.BTNE11.UseVisualStyleBackColor = false;
            this.BTNE11.Click += new System.EventHandler(this.BTNE11_Click);
            // 
            // BTNE10
            // 
            this.BTNE10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE10.Location = new System.Drawing.Point(391, 223);
            this.BTNE10.Name = "BTNE10";
            this.BTNE10.Size = new System.Drawing.Size(32, 25);
            this.BTNE10.TabIndex = 69;
            this.BTNE10.Text = " ";
            this.BTNE10.UseVisualStyleBackColor = false;
            this.BTNE10.Click += new System.EventHandler(this.BTNE10_Click);
            // 
            // BTNE9
            // 
            this.BTNE9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE9.Location = new System.Drawing.Point(353, 223);
            this.BTNE9.Name = "BTNE9";
            this.BTNE9.Size = new System.Drawing.Size(32, 25);
            this.BTNE9.TabIndex = 68;
            this.BTNE9.Text = " ";
            this.BTNE9.UseVisualStyleBackColor = false;
            this.BTNE9.Click += new System.EventHandler(this.BTNE9_Click);
            // 
            // BTNE8
            // 
            this.BTNE8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE8.Location = new System.Drawing.Point(315, 223);
            this.BTNE8.Name = "BTNE8";
            this.BTNE8.Size = new System.Drawing.Size(32, 25);
            this.BTNE8.TabIndex = 67;
            this.BTNE8.Text = " ";
            this.BTNE8.UseVisualStyleBackColor = false;
            this.BTNE8.Click += new System.EventHandler(this.BTNE8_Click);
            // 
            // BTNE7
            // 
            this.BTNE7.AccessibleDescription = "";
            this.BTNE7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE7.Location = new System.Drawing.Point(277, 223);
            this.BTNE7.Name = "BTNE7";
            this.BTNE7.Size = new System.Drawing.Size(32, 25);
            this.BTNE7.TabIndex = 66;
            this.BTNE7.Text = " ";
            this.BTNE7.UseVisualStyleBackColor = false;
            this.BTNE7.Click += new System.EventHandler(this.BTNE7_Click);
            // 
            // BTNE6
            // 
            this.BTNE6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE6.Location = new System.Drawing.Point(239, 223);
            this.BTNE6.Name = "BTNE6";
            this.BTNE6.Size = new System.Drawing.Size(32, 25);
            this.BTNE6.TabIndex = 65;
            this.BTNE6.Text = " ";
            this.BTNE6.UseVisualStyleBackColor = false;
            this.BTNE6.Click += new System.EventHandler(this.BTNE6_Click);
            // 
            // BTNE5
            // 
            this.BTNE5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE5.Location = new System.Drawing.Point(201, 223);
            this.BTNE5.Name = "BTNE5";
            this.BTNE5.Size = new System.Drawing.Size(32, 25);
            this.BTNE5.TabIndex = 64;
            this.BTNE5.Text = " ";
            this.BTNE5.UseVisualStyleBackColor = false;
            this.BTNE5.Click += new System.EventHandler(this.BTNE5_Click);
            // 
            // BTNE4
            // 
            this.BTNE4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE4.Location = new System.Drawing.Point(163, 223);
            this.BTNE4.Name = "BTNE4";
            this.BTNE4.Size = new System.Drawing.Size(32, 25);
            this.BTNE4.TabIndex = 63;
            this.BTNE4.Text = " ";
            this.BTNE4.UseVisualStyleBackColor = false;
            this.BTNE4.Click += new System.EventHandler(this.BTNE4_Click);
            // 
            // BTNE3
            // 
            this.BTNE3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE3.Location = new System.Drawing.Point(125, 223);
            this.BTNE3.Name = "BTNE3";
            this.BTNE3.Size = new System.Drawing.Size(32, 25);
            this.BTNE3.TabIndex = 62;
            this.BTNE3.Text = " ";
            this.BTNE3.UseVisualStyleBackColor = false;
            this.BTNE3.Click += new System.EventHandler(this.BTNE3_Click);
            // 
            // BTNE2
            // 
            this.BTNE2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE2.Location = new System.Drawing.Point(87, 223);
            this.BTNE2.Name = "BTNE2";
            this.BTNE2.Size = new System.Drawing.Size(32, 25);
            this.BTNE2.TabIndex = 61;
            this.BTNE2.Text = " ";
            this.BTNE2.UseVisualStyleBackColor = false;
            this.BTNE2.Click += new System.EventHandler(this.BTNE2_Click);
            // 
            // BTNE1
            // 
            this.BTNE1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNE1.Location = new System.Drawing.Point(49, 223);
            this.BTNE1.Name = "BTNE1";
            this.BTNE1.Size = new System.Drawing.Size(32, 25);
            this.BTNE1.TabIndex = 60;
            this.BTNE1.Text = " ";
            this.BTNE1.UseVisualStyleBackColor = false;
            this.BTNE1.Click += new System.EventHandler(this.BTNE1_Click);
            // 
            // BTND15
            // 
            this.BTND15.BackColor = System.Drawing.Color.LightGreen;
            this.BTND15.Location = new System.Drawing.Point(580, 192);
            this.BTND15.Name = "BTND15";
            this.BTND15.Size = new System.Drawing.Size(32, 25);
            this.BTND15.TabIndex = 59;
            this.BTND15.Text = " ";
            this.BTND15.UseVisualStyleBackColor = false;
            this.BTND15.Click += new System.EventHandler(this.BTND15_Click);
            // 
            // BTND14
            // 
            this.BTND14.BackColor = System.Drawing.Color.LightGreen;
            this.BTND14.Location = new System.Drawing.Point(542, 192);
            this.BTND14.Name = "BTND14";
            this.BTND14.Size = new System.Drawing.Size(32, 25);
            this.BTND14.TabIndex = 58;
            this.BTND14.Text = " ";
            this.BTND14.UseVisualStyleBackColor = false;
            this.BTND14.Click += new System.EventHandler(this.BTND14_Click);
            // 
            // BTND13
            // 
            this.BTND13.BackColor = System.Drawing.Color.LightGreen;
            this.BTND13.Location = new System.Drawing.Point(504, 192);
            this.BTND13.Name = "BTND13";
            this.BTND13.Size = new System.Drawing.Size(32, 25);
            this.BTND13.TabIndex = 57;
            this.BTND13.Text = " ";
            this.BTND13.UseVisualStyleBackColor = false;
            this.BTND13.Click += new System.EventHandler(this.BTND13_Click);
            // 
            // BTND12
            // 
            this.BTND12.BackColor = System.Drawing.Color.LightGreen;
            this.BTND12.Location = new System.Drawing.Point(467, 192);
            this.BTND12.Name = "BTND12";
            this.BTND12.Size = new System.Drawing.Size(32, 25);
            this.BTND12.TabIndex = 56;
            this.BTND12.Text = " ";
            this.BTND12.UseVisualStyleBackColor = false;
            this.BTND12.Click += new System.EventHandler(this.BTND12_Click);
            // 
            // BTND11
            // 
            this.BTND11.BackColor = System.Drawing.Color.LightGreen;
            this.BTND11.Location = new System.Drawing.Point(429, 192);
            this.BTND11.Name = "BTND11";
            this.BTND11.Size = new System.Drawing.Size(32, 25);
            this.BTND11.TabIndex = 55;
            this.BTND11.Text = " ";
            this.BTND11.UseVisualStyleBackColor = false;
            this.BTND11.Click += new System.EventHandler(this.BTND11_Click);
            // 
            // BTND10
            // 
            this.BTND10.BackColor = System.Drawing.Color.LightGreen;
            this.BTND10.Location = new System.Drawing.Point(391, 192);
            this.BTND10.Name = "BTND10";
            this.BTND10.Size = new System.Drawing.Size(32, 25);
            this.BTND10.TabIndex = 54;
            this.BTND10.Text = " ";
            this.BTND10.UseVisualStyleBackColor = false;
            this.BTND10.Click += new System.EventHandler(this.BTND10_Click);
            // 
            // BTND9
            // 
            this.BTND9.BackColor = System.Drawing.Color.LightGreen;
            this.BTND9.Location = new System.Drawing.Point(353, 192);
            this.BTND9.Name = "BTND9";
            this.BTND9.Size = new System.Drawing.Size(32, 25);
            this.BTND9.TabIndex = 53;
            this.BTND9.Text = " ";
            this.BTND9.UseVisualStyleBackColor = false;
            this.BTND9.Click += new System.EventHandler(this.BTND9_Click);
            // 
            // BTND8
            // 
            this.BTND8.BackColor = System.Drawing.Color.LightGreen;
            this.BTND8.Location = new System.Drawing.Point(315, 192);
            this.BTND8.Name = "BTND8";
            this.BTND8.Size = new System.Drawing.Size(32, 25);
            this.BTND8.TabIndex = 52;
            this.BTND8.Text = " ";
            this.BTND8.UseVisualStyleBackColor = false;
            this.BTND8.Click += new System.EventHandler(this.BTND8_Click);
            // 
            // BTND7
            // 
            this.BTND7.BackColor = System.Drawing.Color.LightGreen;
            this.BTND7.Location = new System.Drawing.Point(277, 192);
            this.BTND7.Name = "BTND7";
            this.BTND7.Size = new System.Drawing.Size(32, 25);
            this.BTND7.TabIndex = 51;
            this.BTND7.Text = " ";
            this.BTND7.UseVisualStyleBackColor = false;
            this.BTND7.Click += new System.EventHandler(this.BTND7_Click);
            // 
            // BTND6
            // 
            this.BTND6.BackColor = System.Drawing.Color.LightGreen;
            this.BTND6.Location = new System.Drawing.Point(239, 192);
            this.BTND6.Name = "BTND6";
            this.BTND6.Size = new System.Drawing.Size(32, 25);
            this.BTND6.TabIndex = 50;
            this.BTND6.Text = " ";
            this.BTND6.UseVisualStyleBackColor = false;
            this.BTND6.Click += new System.EventHandler(this.BTND6_Click);
            // 
            // BTND5
            // 
            this.BTND5.BackColor = System.Drawing.Color.LightGreen;
            this.BTND5.Location = new System.Drawing.Point(201, 192);
            this.BTND5.Name = "BTND5";
            this.BTND5.Size = new System.Drawing.Size(32, 25);
            this.BTND5.TabIndex = 49;
            this.BTND5.Text = " ";
            this.BTND5.UseVisualStyleBackColor = false;
            this.BTND5.Click += new System.EventHandler(this.BTND5_Click);
            // 
            // BTND4
            // 
            this.BTND4.BackColor = System.Drawing.Color.LightGreen;
            this.BTND4.Location = new System.Drawing.Point(163, 192);
            this.BTND4.Name = "BTND4";
            this.BTND4.Size = new System.Drawing.Size(32, 25);
            this.BTND4.TabIndex = 48;
            this.BTND4.Text = " ";
            this.BTND4.UseVisualStyleBackColor = false;
            this.BTND4.Click += new System.EventHandler(this.BTND4_Click);
            // 
            // BTND3
            // 
            this.BTND3.BackColor = System.Drawing.Color.LightGreen;
            this.BTND3.Location = new System.Drawing.Point(125, 192);
            this.BTND3.Name = "BTND3";
            this.BTND3.Size = new System.Drawing.Size(32, 25);
            this.BTND3.TabIndex = 47;
            this.BTND3.Text = " ";
            this.BTND3.UseVisualStyleBackColor = false;
            this.BTND3.Click += new System.EventHandler(this.BTND3_Click);
            // 
            // BTND2
            // 
            this.BTND2.BackColor = System.Drawing.Color.LightGreen;
            this.BTND2.Location = new System.Drawing.Point(87, 192);
            this.BTND2.Name = "BTND2";
            this.BTND2.Size = new System.Drawing.Size(32, 25);
            this.BTND2.TabIndex = 46;
            this.BTND2.Text = " ";
            this.BTND2.UseVisualStyleBackColor = false;
            this.BTND2.Click += new System.EventHandler(this.BTND2_Click);
            // 
            // BTND1
            // 
            this.BTND1.BackColor = System.Drawing.Color.LightGreen;
            this.BTND1.Location = new System.Drawing.Point(49, 192);
            this.BTND1.Name = "BTND1";
            this.BTND1.Size = new System.Drawing.Size(32, 25);
            this.BTND1.TabIndex = 45;
            this.BTND1.Text = " ";
            this.BTND1.UseVisualStyleBackColor = false;
            this.BTND1.Click += new System.EventHandler(this.BTND1_Click);
            // 
            // BTNC15
            // 
            this.BTNC15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC15.Location = new System.Drawing.Point(580, 161);
            this.BTNC15.Name = "BTNC15";
            this.BTNC15.Size = new System.Drawing.Size(32, 25);
            this.BTNC15.TabIndex = 44;
            this.BTNC15.Text = " ";
            this.BTNC15.UseVisualStyleBackColor = false;
            this.BTNC15.Click += new System.EventHandler(this.BTNC15_Click);
            // 
            // BTNC14
            // 
            this.BTNC14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC14.Location = new System.Drawing.Point(542, 161);
            this.BTNC14.Name = "BTNC14";
            this.BTNC14.Size = new System.Drawing.Size(32, 25);
            this.BTNC14.TabIndex = 43;
            this.BTNC14.Text = " ";
            this.BTNC14.UseVisualStyleBackColor = false;
            this.BTNC14.Click += new System.EventHandler(this.BTNC14_Click);
            // 
            // BTNC13
            // 
            this.BTNC13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC13.Location = new System.Drawing.Point(504, 161);
            this.BTNC13.Name = "BTNC13";
            this.BTNC13.Size = new System.Drawing.Size(32, 25);
            this.BTNC13.TabIndex = 42;
            this.BTNC13.Text = " ";
            this.BTNC13.UseVisualStyleBackColor = false;
            this.BTNC13.Click += new System.EventHandler(this.BTNC13_Click);
            // 
            // BTNC12
            // 
            this.BTNC12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC12.Location = new System.Drawing.Point(467, 161);
            this.BTNC12.Name = "BTNC12";
            this.BTNC12.Size = new System.Drawing.Size(32, 25);
            this.BTNC12.TabIndex = 41;
            this.BTNC12.Text = " ";
            this.BTNC12.UseVisualStyleBackColor = false;
            this.BTNC12.Click += new System.EventHandler(this.BTNC12_Click);
            // 
            // BTNC11
            // 
            this.BTNC11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC11.Location = new System.Drawing.Point(429, 161);
            this.BTNC11.Name = "BTNC11";
            this.BTNC11.Size = new System.Drawing.Size(32, 25);
            this.BTNC11.TabIndex = 40;
            this.BTNC11.Text = " ";
            this.BTNC11.UseVisualStyleBackColor = false;
            this.BTNC11.Click += new System.EventHandler(this.BTNC11_Click);
            // 
            // BTNC10
            // 
            this.BTNC10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC10.Location = new System.Drawing.Point(391, 161);
            this.BTNC10.Name = "BTNC10";
            this.BTNC10.Size = new System.Drawing.Size(32, 25);
            this.BTNC10.TabIndex = 39;
            this.BTNC10.Text = " ";
            this.BTNC10.UseVisualStyleBackColor = false;
            this.BTNC10.Click += new System.EventHandler(this.BTNC10_Click);
            // 
            // BTNC9
            // 
            this.BTNC9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC9.Location = new System.Drawing.Point(353, 161);
            this.BTNC9.Name = "BTNC9";
            this.BTNC9.Size = new System.Drawing.Size(32, 25);
            this.BTNC9.TabIndex = 38;
            this.BTNC9.Text = " ";
            this.BTNC9.UseVisualStyleBackColor = false;
            this.BTNC9.Click += new System.EventHandler(this.BTNC9_Click);
            // 
            // BTNC8
            // 
            this.BTNC8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC8.Location = new System.Drawing.Point(315, 161);
            this.BTNC8.Name = "BTNC8";
            this.BTNC8.Size = new System.Drawing.Size(32, 25);
            this.BTNC8.TabIndex = 37;
            this.BTNC8.Text = " ";
            this.BTNC8.UseVisualStyleBackColor = false;
            this.BTNC8.Click += new System.EventHandler(this.BTNC8_Click);
            // 
            // BTNC7
            // 
            this.BTNC7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC7.Location = new System.Drawing.Point(277, 161);
            this.BTNC7.Name = "BTNC7";
            this.BTNC7.Size = new System.Drawing.Size(32, 25);
            this.BTNC7.TabIndex = 36;
            this.BTNC7.Text = " ";
            this.BTNC7.UseVisualStyleBackColor = false;
            this.BTNC7.Click += new System.EventHandler(this.BTNC7_Click);
            // 
            // BTNC6
            // 
            this.BTNC6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC6.Location = new System.Drawing.Point(239, 161);
            this.BTNC6.Name = "BTNC6";
            this.BTNC6.Size = new System.Drawing.Size(32, 25);
            this.BTNC6.TabIndex = 35;
            this.BTNC6.Text = " ";
            this.BTNC6.UseVisualStyleBackColor = false;
            this.BTNC6.Click += new System.EventHandler(this.BTNC6_Click);
            // 
            // BTNC5
            // 
            this.BTNC5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC5.Location = new System.Drawing.Point(201, 161);
            this.BTNC5.Name = "BTNC5";
            this.BTNC5.Size = new System.Drawing.Size(32, 25);
            this.BTNC5.TabIndex = 34;
            this.BTNC5.Text = " ";
            this.BTNC5.UseVisualStyleBackColor = false;
            this.BTNC5.Click += new System.EventHandler(this.BTNC5_Click);
            // 
            // BTNC4
            // 
            this.BTNC4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC4.Location = new System.Drawing.Point(163, 161);
            this.BTNC4.Name = "BTNC4";
            this.BTNC4.Size = new System.Drawing.Size(32, 25);
            this.BTNC4.TabIndex = 33;
            this.BTNC4.Text = " ";
            this.BTNC4.UseVisualStyleBackColor = false;
            this.BTNC4.Click += new System.EventHandler(this.BTNC4_Click);
            // 
            // BTNC3
            // 
            this.BTNC3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC3.Location = new System.Drawing.Point(125, 161);
            this.BTNC3.Name = "BTNC3";
            this.BTNC3.Size = new System.Drawing.Size(32, 25);
            this.BTNC3.TabIndex = 32;
            this.BTNC3.Text = " ";
            this.BTNC3.UseVisualStyleBackColor = false;
            this.BTNC3.Click += new System.EventHandler(this.BTNC3_Click);
            // 
            // BTNC2
            // 
            this.BTNC2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC2.Location = new System.Drawing.Point(87, 161);
            this.BTNC2.Name = "BTNC2";
            this.BTNC2.Size = new System.Drawing.Size(32, 25);
            this.BTNC2.TabIndex = 31;
            this.BTNC2.Text = " ";
            this.BTNC2.UseVisualStyleBackColor = false;
            this.BTNC2.Click += new System.EventHandler(this.BTNC2_Click);
            // 
            // BTNC1
            // 
            this.BTNC1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNC1.Location = new System.Drawing.Point(49, 161);
            this.BTNC1.Name = "BTNC1";
            this.BTNC1.Size = new System.Drawing.Size(32, 25);
            this.BTNC1.TabIndex = 30;
            this.BTNC1.Text = " ";
            this.BTNC1.UseVisualStyleBackColor = false;
            this.BTNC1.Click += new System.EventHandler(this.BTNC1_Click);
            // 
            // BTNB15
            // 
            this.BTNB15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB15.Location = new System.Drawing.Point(580, 130);
            this.BTNB15.Name = "BTNB15";
            this.BTNB15.Size = new System.Drawing.Size(32, 25);
            this.BTNB15.TabIndex = 29;
            this.BTNB15.Text = " ";
            this.BTNB15.UseVisualStyleBackColor = false;
            this.BTNB15.Click += new System.EventHandler(this.BTNB15_Click);
            // 
            // BTNB14
            // 
            this.BTNB14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB14.Location = new System.Drawing.Point(542, 130);
            this.BTNB14.Name = "BTNB14";
            this.BTNB14.Size = new System.Drawing.Size(32, 25);
            this.BTNB14.TabIndex = 28;
            this.BTNB14.Text = " ";
            this.BTNB14.UseVisualStyleBackColor = false;
            this.BTNB14.Click += new System.EventHandler(this.BTNB14_Click);
            // 
            // BTNB13
            // 
            this.BTNB13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB13.Location = new System.Drawing.Point(504, 130);
            this.BTNB13.Name = "BTNB13";
            this.BTNB13.Size = new System.Drawing.Size(32, 25);
            this.BTNB13.TabIndex = 27;
            this.BTNB13.Text = " ";
            this.BTNB13.UseVisualStyleBackColor = false;
            this.BTNB13.Click += new System.EventHandler(this.BTNB13_Click);
            // 
            // BTNB12
            // 
            this.BTNB12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB12.Location = new System.Drawing.Point(467, 130);
            this.BTNB12.Name = "BTNB12";
            this.BTNB12.Size = new System.Drawing.Size(32, 25);
            this.BTNB12.TabIndex = 26;
            this.BTNB12.Text = " ";
            this.BTNB12.UseVisualStyleBackColor = false;
            this.BTNB12.Click += new System.EventHandler(this.BTNB12_Click);
            // 
            // BTNB11
            // 
            this.BTNB11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB11.Location = new System.Drawing.Point(429, 130);
            this.BTNB11.Name = "BTNB11";
            this.BTNB11.Size = new System.Drawing.Size(32, 25);
            this.BTNB11.TabIndex = 25;
            this.BTNB11.Text = " ";
            this.BTNB11.UseVisualStyleBackColor = false;
            this.BTNB11.Click += new System.EventHandler(this.BTNB11_Click);
            // 
            // BTNB10
            // 
            this.BTNB10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB10.Location = new System.Drawing.Point(391, 130);
            this.BTNB10.Name = "BTNB10";
            this.BTNB10.Size = new System.Drawing.Size(32, 25);
            this.BTNB10.TabIndex = 24;
            this.BTNB10.Text = " ";
            this.BTNB10.UseVisualStyleBackColor = false;
            this.BTNB10.Click += new System.EventHandler(this.BTNB10_Click);
            // 
            // BTNB9
            // 
            this.BTNB9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB9.Location = new System.Drawing.Point(353, 130);
            this.BTNB9.Name = "BTNB9";
            this.BTNB9.Size = new System.Drawing.Size(32, 25);
            this.BTNB9.TabIndex = 23;
            this.BTNB9.Text = " ";
            this.BTNB9.UseVisualStyleBackColor = false;
            this.BTNB9.Click += new System.EventHandler(this.BTNB9_Click);
            // 
            // BTNB8
            // 
            this.BTNB8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB8.Location = new System.Drawing.Point(315, 130);
            this.BTNB8.Name = "BTNB8";
            this.BTNB8.Size = new System.Drawing.Size(32, 25);
            this.BTNB8.TabIndex = 22;
            this.BTNB8.Text = " ";
            this.BTNB8.UseVisualStyleBackColor = false;
            this.BTNB8.Click += new System.EventHandler(this.BTNB8_Click);
            // 
            // BTNB7
            // 
            this.BTNB7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB7.Location = new System.Drawing.Point(277, 130);
            this.BTNB7.Name = "BTNB7";
            this.BTNB7.Size = new System.Drawing.Size(32, 25);
            this.BTNB7.TabIndex = 21;
            this.BTNB7.Text = " ";
            this.BTNB7.UseVisualStyleBackColor = false;
            this.BTNB7.Click += new System.EventHandler(this.BTNB7_Click);
            // 
            // BTNB6
            // 
            this.BTNB6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB6.Location = new System.Drawing.Point(239, 130);
            this.BTNB6.Name = "BTNB6";
            this.BTNB6.Size = new System.Drawing.Size(32, 25);
            this.BTNB6.TabIndex = 20;
            this.BTNB6.Text = " ";
            this.BTNB6.UseVisualStyleBackColor = false;
            this.BTNB6.Click += new System.EventHandler(this.BTNB6_Click);
            // 
            // BTNB5
            // 
            this.BTNB5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB5.Location = new System.Drawing.Point(201, 130);
            this.BTNB5.Name = "BTNB5";
            this.BTNB5.Size = new System.Drawing.Size(32, 25);
            this.BTNB5.TabIndex = 19;
            this.BTNB5.Text = " ";
            this.BTNB5.UseVisualStyleBackColor = false;
            this.BTNB5.Click += new System.EventHandler(this.BTNB5_Click);
            // 
            // BTNB4
            // 
            this.BTNB4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB4.Location = new System.Drawing.Point(163, 130);
            this.BTNB4.Name = "BTNB4";
            this.BTNB4.Size = new System.Drawing.Size(32, 25);
            this.BTNB4.TabIndex = 18;
            this.BTNB4.Text = " ";
            this.BTNB4.UseVisualStyleBackColor = false;
            this.BTNB4.Click += new System.EventHandler(this.BTNB4_Click);
            // 
            // BTNB3
            // 
            this.BTNB3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB3.Location = new System.Drawing.Point(125, 130);
            this.BTNB3.Name = "BTNB3";
            this.BTNB3.Size = new System.Drawing.Size(32, 25);
            this.BTNB3.TabIndex = 17;
            this.BTNB3.Text = " ";
            this.BTNB3.UseVisualStyleBackColor = false;
            this.BTNB3.Click += new System.EventHandler(this.BTNB3_Click);
            // 
            // BTNB2
            // 
            this.BTNB2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB2.Location = new System.Drawing.Point(87, 130);
            this.BTNB2.Name = "BTNB2";
            this.BTNB2.Size = new System.Drawing.Size(32, 25);
            this.BTNB2.TabIndex = 16;
            this.BTNB2.Text = " ";
            this.BTNB2.UseVisualStyleBackColor = false;
            this.BTNB2.Click += new System.EventHandler(this.BTNB2_Click);
            // 
            // BTNB1
            // 
            this.BTNB1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNB1.Location = new System.Drawing.Point(49, 130);
            this.BTNB1.Name = "BTNB1";
            this.BTNB1.Size = new System.Drawing.Size(32, 25);
            this.BTNB1.TabIndex = 15;
            this.BTNB1.Text = " ";
            this.BTNB1.UseVisualStyleBackColor = false;
            this.BTNB1.Click += new System.EventHandler(this.BTNB1_Click);
            // 
            // BTNA15
            // 
            this.BTNA15.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA15.Location = new System.Drawing.Point(580, 99);
            this.BTNA15.Name = "BTNA15";
            this.BTNA15.Size = new System.Drawing.Size(32, 25);
            this.BTNA15.TabIndex = 14;
            this.BTNA15.Text = " ";
            this.BTNA15.UseVisualStyleBackColor = false;
            this.BTNA15.Click += new System.EventHandler(this.BTNA15_Click);
            // 
            // BTNA14
            // 
            this.BTNA14.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA14.Location = new System.Drawing.Point(542, 99);
            this.BTNA14.Name = "BTNA14";
            this.BTNA14.Size = new System.Drawing.Size(32, 25);
            this.BTNA14.TabIndex = 13;
            this.BTNA14.Text = " ";
            this.BTNA14.UseVisualStyleBackColor = false;
            this.BTNA14.Click += new System.EventHandler(this.BTNA14_Click);
            // 
            // BTNA13
            // 
            this.BTNA13.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA13.Location = new System.Drawing.Point(504, 99);
            this.BTNA13.Name = "BTNA13";
            this.BTNA13.Size = new System.Drawing.Size(32, 25);
            this.BTNA13.TabIndex = 12;
            this.BTNA13.Text = " ";
            this.BTNA13.UseVisualStyleBackColor = false;
            this.BTNA13.Click += new System.EventHandler(this.BTNA13_Click);
            // 
            // BTNA12
            // 
            this.BTNA12.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA12.Location = new System.Drawing.Point(467, 99);
            this.BTNA12.Name = "BTNA12";
            this.BTNA12.Size = new System.Drawing.Size(32, 25);
            this.BTNA12.TabIndex = 11;
            this.BTNA12.Text = " ";
            this.BTNA12.UseVisualStyleBackColor = false;
            this.BTNA12.Click += new System.EventHandler(this.BTNA12_Click);
            // 
            // BTNA11
            // 
            this.BTNA11.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA11.Location = new System.Drawing.Point(429, 99);
            this.BTNA11.Name = "BTNA11";
            this.BTNA11.Size = new System.Drawing.Size(32, 25);
            this.BTNA11.TabIndex = 10;
            this.BTNA11.Text = " ";
            this.BTNA11.UseVisualStyleBackColor = false;
            this.BTNA11.Click += new System.EventHandler(this.BTNA11_Click);
            // 
            // BTNA10
            // 
            this.BTNA10.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA10.Location = new System.Drawing.Point(391, 99);
            this.BTNA10.Name = "BTNA10";
            this.BTNA10.Size = new System.Drawing.Size(32, 25);
            this.BTNA10.TabIndex = 9;
            this.BTNA10.Text = " ";
            this.BTNA10.UseVisualStyleBackColor = false;
            this.BTNA10.Click += new System.EventHandler(this.BTNA10_Click);
            // 
            // BTNA9
            // 
            this.BTNA9.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA9.Location = new System.Drawing.Point(353, 99);
            this.BTNA9.Name = "BTNA9";
            this.BTNA9.Size = new System.Drawing.Size(32, 25);
            this.BTNA9.TabIndex = 8;
            this.BTNA9.Text = " ";
            this.BTNA9.UseVisualStyleBackColor = false;
            this.BTNA9.Click += new System.EventHandler(this.BTNA9_Click);
            // 
            // BTNA8
            // 
            this.BTNA8.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA8.Location = new System.Drawing.Point(315, 99);
            this.BTNA8.Name = "BTNA8";
            this.BTNA8.Size = new System.Drawing.Size(32, 25);
            this.BTNA8.TabIndex = 7;
            this.BTNA8.Text = " ";
            this.BTNA8.UseVisualStyleBackColor = false;
            this.BTNA8.Click += new System.EventHandler(this.BTNA8_Click);
            // 
            // BTNA7
            // 
            this.BTNA7.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA7.Location = new System.Drawing.Point(277, 99);
            this.BTNA7.Name = "BTNA7";
            this.BTNA7.Size = new System.Drawing.Size(32, 25);
            this.BTNA7.TabIndex = 6;
            this.BTNA7.Text = " ";
            this.BTNA7.UseVisualStyleBackColor = false;
            this.BTNA7.Click += new System.EventHandler(this.BTNA7_Click);
            // 
            // BTNA6
            // 
            this.BTNA6.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA6.Location = new System.Drawing.Point(239, 99);
            this.BTNA6.Name = "BTNA6";
            this.BTNA6.Size = new System.Drawing.Size(32, 25);
            this.BTNA6.TabIndex = 5;
            this.BTNA6.Text = " ";
            this.BTNA6.UseVisualStyleBackColor = false;
            this.BTNA6.Click += new System.EventHandler(this.BTNA6_Click);
            // 
            // BTNA5
            // 
            this.BTNA5.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA5.Location = new System.Drawing.Point(201, 99);
            this.BTNA5.Name = "BTNA5";
            this.BTNA5.Size = new System.Drawing.Size(32, 25);
            this.BTNA5.TabIndex = 4;
            this.BTNA5.Text = " ";
            this.BTNA5.UseVisualStyleBackColor = false;
            this.BTNA5.Click += new System.EventHandler(this.BTNA5_Click);
            // 
            // BTNA4
            // 
            this.BTNA4.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA4.Location = new System.Drawing.Point(163, 99);
            this.BTNA4.Name = "BTNA4";
            this.BTNA4.Size = new System.Drawing.Size(32, 25);
            this.BTNA4.TabIndex = 3;
            this.BTNA4.Text = " ";
            this.BTNA4.UseVisualStyleBackColor = false;
            this.BTNA4.Click += new System.EventHandler(this.BTNA4_Click);
            // 
            // BTNA3
            // 
            this.BTNA3.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA3.Location = new System.Drawing.Point(125, 99);
            this.BTNA3.Name = "BTNA3";
            this.BTNA3.Size = new System.Drawing.Size(32, 25);
            this.BTNA3.TabIndex = 2;
            this.BTNA3.Text = " ";
            this.BTNA3.UseVisualStyleBackColor = false;
            this.BTNA3.Click += new System.EventHandler(this.BTNA3_Click);
            // 
            // BTNA2
            // 
            this.BTNA2.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA2.Location = new System.Drawing.Point(87, 99);
            this.BTNA2.Name = "BTNA2";
            this.BTNA2.Size = new System.Drawing.Size(32, 25);
            this.BTNA2.TabIndex = 1;
            this.BTNA2.Text = " ";
            this.BTNA2.UseVisualStyleBackColor = false;
            this.BTNA2.Click += new System.EventHandler(this.BTNA2_Click);
            // 
            // BTNA1
            // 
            this.BTNA1.BackColor = System.Drawing.Color.LightGreen;
            this.BTNA1.Location = new System.Drawing.Point(49, 99);
            this.BTNA1.Name = "BTNA1";
            this.BTNA1.Size = new System.Drawing.Size(32, 25);
            this.BTNA1.TabIndex = 0;
            this.BTNA1.Text = " ";
            this.BTNA1.UseVisualStyleBackColor = false;
            this.BTNA1.Click += new System.EventHandler(this.BTNA1_Click);
            // 
            // button151
            // 
            this.button151.BackColor = System.Drawing.Color.LightGreen;
            this.button151.Enabled = false;
            this.button151.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button151.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button151.Location = new System.Drawing.Point(684, 55);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(32, 25);
            this.button151.TabIndex = 15;
            this.button151.Text = " ";
            this.button151.UseVisualStyleBackColor = false;
            // 
            // button152
            // 
            this.button152.BackColor = System.Drawing.Color.Red;
            this.button152.Enabled = false;
            this.button152.Location = new System.Drawing.Point(684, 92);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(32, 25);
            this.button152.TabIndex = 16;
            this.button152.Text = " ";
            this.button152.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(653, 32);
            this.label1.TabIndex = 17;
            this.label1.Text = "Sistema de reservación de asientos para teatro";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(722, 57);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(141, 20);
            this.label27.TabIndex = 18;
            this.label27.Text = "Asiento Disponible";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(722, 97);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(132, 20);
            this.label28.TabIndex = 19;
            this.label28.Text = "Asiento Ocupado";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.TBnombre);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.BTNno);
            this.groupBox1.Controls.Add(this.BTNsi);
            this.groupBox1.Controls.Add(this.LBLaccion);
            this.groupBox1.Controls.Add(this.TBestadoasiento);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.TBnumeroasiento);
            this.groupBox1.Location = new System.Drawing.Point(671, 138);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(247, 376);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Selección de asiento";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.Color.Red;
            this.label32.Location = new System.Drawing.Point(130, 203);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(15, 20);
            this.label32.TabIndex = 7;
            this.label32.Text = "*";
            // 
            // TBnombre
            // 
            this.TBnombre.AcceptsReturn = true;
            this.TBnombre.Font = new System.Drawing.Font("Arial Narrow", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBnombre.Location = new System.Drawing.Point(13, 236);
            this.TBnombre.Name = "TBnombre";
            this.TBnombre.Size = new System.Drawing.Size(228, 26);
            this.TBnombre.TabIndex = 1;
            this.TBnombre.TextChanged += new System.EventHandler(this.TBnombre_TextChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(11, 202);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(119, 20);
            this.label31.TabIndex = 6;
            this.label31.Text = "Nombre cliente:";
            // 
            // BTNno
            // 
            this.BTNno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNno.Location = new System.Drawing.Point(142, 325);
            this.BTNno.Name = "BTNno";
            this.BTNno.Size = new System.Drawing.Size(74, 38);
            this.BTNno.TabIndex = 3;
            this.BTNno.Text = "NO";
            this.BTNno.UseVisualStyleBackColor = true;
            this.BTNno.Click += new System.EventHandler(this.BTNno_Click);
            // 
            // BTNsi
            // 
            this.BTNsi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNsi.Location = new System.Drawing.Point(31, 325);
            this.BTNsi.Name = "BTNsi";
            this.BTNsi.Size = new System.Drawing.Size(74, 38);
            this.BTNsi.TabIndex = 2;
            this.BTNsi.Text = "SI";
            this.BTNsi.UseVisualStyleBackColor = true;
            this.BTNsi.Click += new System.EventHandler(this.BTNsi_Click);
            // 
            // LBLaccion
            // 
            this.LBLaccion.AutoSize = true;
            this.LBLaccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLaccion.Location = new System.Drawing.Point(10, 289);
            this.LBLaccion.Name = "LBLaccion";
            this.LBLaccion.Size = new System.Drawing.Size(209, 25);
            this.LBLaccion.TabIndex = 3;
            this.LBLaccion.Text = "Esperando selección...";
            // 
            // TBestadoasiento
            // 
            this.TBestadoasiento.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBestadoasiento.Location = new System.Drawing.Point(32, 140);
            this.TBestadoasiento.Name = "TBestadoasiento";
            this.TBestadoasiento.ReadOnly = true;
            this.TBestadoasiento.Size = new System.Drawing.Size(182, 40);
            this.TBestadoasiento.TabIndex = 2;
            this.TBestadoasiento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(11, 109);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(145, 20);
            this.label30.TabIndex = 1;
            this.label30.Text = "Estado del asiento:";
            // 
            // TBnumeroasiento
            // 
            this.TBnumeroasiento.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBnumeroasiento.Location = new System.Drawing.Point(53, 34);
            this.TBnumeroasiento.Name = "TBnumeroasiento";
            this.TBnumeroasiento.ReadOnly = true;
            this.TBnumeroasiento.Size = new System.Drawing.Size(138, 63);
            this.TBnumeroasiento.TabIndex = 0;
            this.TBnumeroasiento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button153
            // 
            this.button153.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button153.Location = new System.Drawing.Point(817, 520);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(99, 38);
            this.button153.TabIndex = 5;
            this.button153.Text = "SALIR";
            this.button153.UseVisualStyleBackColor = true;
            this.button153.Click += new System.EventHandler(this.button153_Click);
            // 
            // BTNlimpia
            // 
            this.BTNlimpia.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNlimpia.ForeColor = System.Drawing.Color.Red;
            this.BTNlimpia.Location = new System.Drawing.Point(673, 521);
            this.BTNlimpia.Name = "BTNlimpia";
            this.BTNlimpia.Size = new System.Drawing.Size(78, 37);
            this.BTNlimpia.TabIndex = 4;
            this.BTNlimpia.Text = "Limpiar";
            this.BTNlimpia.UseVisualStyleBackColor = true;
            this.BTNlimpia.Click += new System.EventHandler(this.BTNlimpia_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 567);
            this.Controls.Add(this.BTNlimpia);
            this.Controls.Add(this.button153);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button152);
            this.Controls.Add(this.button151);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Reserva de asientos Teatro";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BTNA1;
        private System.Windows.Forms.Button BTNJ15;
        private System.Windows.Forms.Button BTNJ14;
        private System.Windows.Forms.Button BTNJ13;
        private System.Windows.Forms.Button BTNJ12;
        private System.Windows.Forms.Button BTNJ11;
        private System.Windows.Forms.Button BTNJ10;
        private System.Windows.Forms.Button BTNJ9;
        private System.Windows.Forms.Button BTNJ8;
        private System.Windows.Forms.Button BTNJ7;
        private System.Windows.Forms.Button BTNJ6;
        private System.Windows.Forms.Button BTNJ5;
        private System.Windows.Forms.Button BTNJ4;
        private System.Windows.Forms.Button BTNJ3;
        private System.Windows.Forms.Button BTNJ2;
        private System.Windows.Forms.Button BTNJ1;
        private System.Windows.Forms.Button BTNI15;
        private System.Windows.Forms.Button BTNI14;
        private System.Windows.Forms.Button BTNI13;
        private System.Windows.Forms.Button BTNI12;
        private System.Windows.Forms.Button BTNI11;
        private System.Windows.Forms.Button BTNI10;
        private System.Windows.Forms.Button BTNI9;
        private System.Windows.Forms.Button BTNI8;
        private System.Windows.Forms.Button BTNI7;
        private System.Windows.Forms.Button BTNI6;
        private System.Windows.Forms.Button BTNI5;
        private System.Windows.Forms.Button BTNI4;
        private System.Windows.Forms.Button BTNI3;
        private System.Windows.Forms.Button BTNI2;
        private System.Windows.Forms.Button BTNI1;
        private System.Windows.Forms.Button BTNH15;
        private System.Windows.Forms.Button BTNH14;
        private System.Windows.Forms.Button BTNH13;
        private System.Windows.Forms.Button BTNH12;
        private System.Windows.Forms.Button BTNH11;
        private System.Windows.Forms.Button BTNH10;
        private System.Windows.Forms.Button BTNH9;
        private System.Windows.Forms.Button BTNH8;
        private System.Windows.Forms.Button BTNH7;
        private System.Windows.Forms.Button BTNH6;
        private System.Windows.Forms.Button BTNH5;
        private System.Windows.Forms.Button BTNH4;
        private System.Windows.Forms.Button BTNH3;
        private System.Windows.Forms.Button BTNH2;
        private System.Windows.Forms.Button BTNH1;
        private System.Windows.Forms.Button BTNG15;
        private System.Windows.Forms.Button BTNG14;
        private System.Windows.Forms.Button BTNG13;
        private System.Windows.Forms.Button BTNG12;
        private System.Windows.Forms.Button BTNG11;
        private System.Windows.Forms.Button BTNG10;
        private System.Windows.Forms.Button BTNG9;
        private System.Windows.Forms.Button BTNG8;
        private System.Windows.Forms.Button BTNG7;
        private System.Windows.Forms.Button BTNG6;
        private System.Windows.Forms.Button BTNG5;
        private System.Windows.Forms.Button BTNG4;
        private System.Windows.Forms.Button BTNG3;
        private System.Windows.Forms.Button BTNG2;
        private System.Windows.Forms.Button BTNG1;
        private System.Windows.Forms.Button BTNF15;
        private System.Windows.Forms.Button BTNF14;
        private System.Windows.Forms.Button BTNF13;
        private System.Windows.Forms.Button BTNF12;
        private System.Windows.Forms.Button BTNF11;
        private System.Windows.Forms.Button BTNF10;
        private System.Windows.Forms.Button BTNF9;
        private System.Windows.Forms.Button BTNF8;
        private System.Windows.Forms.Button BTNF7;
        private System.Windows.Forms.Button BTNF6;
        private System.Windows.Forms.Button BTNF5;
        private System.Windows.Forms.Button BTNF4;
        private System.Windows.Forms.Button BTNF3;
        private System.Windows.Forms.Button BTNF2;
        private System.Windows.Forms.Button BTNF1;
        private System.Windows.Forms.Button BTNE15;
        private System.Windows.Forms.Button BTNE14;
        private System.Windows.Forms.Button BTNE13;
        private System.Windows.Forms.Button BTNE12;
        private System.Windows.Forms.Button BTNE11;
        private System.Windows.Forms.Button BTNE10;
        private System.Windows.Forms.Button BTNE9;
        private System.Windows.Forms.Button BTNE8;
        private System.Windows.Forms.Button BTNE7;
        private System.Windows.Forms.Button BTNE6;
        private System.Windows.Forms.Button BTNE5;
        private System.Windows.Forms.Button BTNE4;
        private System.Windows.Forms.Button BTNE3;
        private System.Windows.Forms.Button BTNE2;
        private System.Windows.Forms.Button BTNE1;
        private System.Windows.Forms.Button BTND15;
        private System.Windows.Forms.Button BTND14;
        private System.Windows.Forms.Button BTND13;
        private System.Windows.Forms.Button BTND12;
        private System.Windows.Forms.Button BTND11;
        private System.Windows.Forms.Button BTND10;
        private System.Windows.Forms.Button BTND9;
        private System.Windows.Forms.Button BTND8;
        private System.Windows.Forms.Button BTND7;
        private System.Windows.Forms.Button BTND6;
        private System.Windows.Forms.Button BTND5;
        private System.Windows.Forms.Button BTND4;
        private System.Windows.Forms.Button BTND3;
        private System.Windows.Forms.Button BTND2;
        private System.Windows.Forms.Button BTND1;
        private System.Windows.Forms.Button BTNC15;
        private System.Windows.Forms.Button BTNC14;
        private System.Windows.Forms.Button BTNC13;
        private System.Windows.Forms.Button BTNC12;
        private System.Windows.Forms.Button BTNC11;
        private System.Windows.Forms.Button BTNC10;
        private System.Windows.Forms.Button BTNC9;
        private System.Windows.Forms.Button BTNC8;
        private System.Windows.Forms.Button BTNC7;
        private System.Windows.Forms.Button BTNC6;
        private System.Windows.Forms.Button BTNC5;
        private System.Windows.Forms.Button BTNC4;
        private System.Windows.Forms.Button BTNC3;
        private System.Windows.Forms.Button BTNC2;
        private System.Windows.Forms.Button BTNC1;
        private System.Windows.Forms.Button BTNB15;
        private System.Windows.Forms.Button BTNB14;
        private System.Windows.Forms.Button BTNB13;
        private System.Windows.Forms.Button BTNB12;
        private System.Windows.Forms.Button BTNB11;
        private System.Windows.Forms.Button BTNB10;
        private System.Windows.Forms.Button BTNB9;
        private System.Windows.Forms.Button BTNB8;
        private System.Windows.Forms.Button BTNB7;
        private System.Windows.Forms.Button BTNB6;
        private System.Windows.Forms.Button BTNB5;
        private System.Windows.Forms.Button BTNB4;
        private System.Windows.Forms.Button BTNB3;
        private System.Windows.Forms.Button BTNB2;
        private System.Windows.Forms.Button BTNB1;
        private System.Windows.Forms.Button BTNA15;
        private System.Windows.Forms.Button BTNA14;
        private System.Windows.Forms.Button BTNA13;
        private System.Windows.Forms.Button BTNA12;
        private System.Windows.Forms.Button BTNA11;
        private System.Windows.Forms.Button BTNA10;
        private System.Windows.Forms.Button BTNA9;
        private System.Windows.Forms.Button BTNA8;
        private System.Windows.Forms.Button BTNA7;
        private System.Windows.Forms.Button BTNA6;
        private System.Windows.Forms.Button BTNA5;
        private System.Windows.Forms.Button BTNA4;
        private System.Windows.Forms.Button BTNA3;
        private System.Windows.Forms.Button BTNA2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TBnumeroasiento;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox TBestadoasiento;
        private System.Windows.Forms.Button BTNsi;
        private System.Windows.Forms.Label LBLaccion;
        private System.Windows.Forms.Button BTNno;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.TextBox TBnombre;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button BTNlimpia;
        private System.Windows.Forms.Label label32;
    }
}

