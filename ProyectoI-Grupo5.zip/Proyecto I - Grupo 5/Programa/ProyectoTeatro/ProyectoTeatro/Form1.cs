﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTeatro
{
    
    public partial class Form1 : Form
    {
        public int Fila = 11;
        public int Columna = 16;
        public static int[,] matriz = new int[10, 15];
        public Form1()
        {
            InitializeComponent();                      
        }

        

        private void label2_Click(object sender, EventArgs e)
        {

        }
       
        private void BTNA1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA1.Name);
            Columna = conexion.AsientoC(BTNA1.Name);
            fi = BTNA1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " "+fi+"-"+co;
            if (BTNA1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";                
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila,Columna);
            }
            conexion.cerrar();
        }

        private void BTNA3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA3.Name);
            Columna = conexion.AsientoC(BTNA3.Name);
            fi = BTNA3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA3.BackColor == Color.LightGreen)
            {

                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA2.Name);
            Columna = conexion.AsientoC(BTNA2.Name);
            fi = BTNA2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA4.Name);
            Columna = conexion.AsientoC(BTNA4.Name);
            fi = BTNA4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void TBnombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void LimpiarPantalla()
        {
            //Cada caja de texto tendra por default un cero
            TBnombre.Text = "";
            TBnumeroasiento.Text = "";
            TBestadoasiento.Text = "";
            LBLaccion.Text = "Esperando selección...";


        }

        private void ActualizaAsientos(int i,int j, int estado)
        {
            if (i == 0 && j == 0 && estado == 1) { BTNA1.BackColor = Color.Red; } 
            if (i == 0 && j == 1 && estado == 1) { BTNA2.BackColor = Color.Red; } 
            if (i == 0 && j == 2 && estado == 1) { BTNA3.BackColor = Color.Red; } 
            if (i == 0 && j == 3 && estado == 1) { BTNA4.BackColor = Color.Red; } 
            if (i == 0 && j == 4 && estado == 1) { BTNA5.BackColor = Color.Red; } 
            if (i == 0 && j == 5 && estado == 1) { BTNA6.BackColor = Color.Red; }
            if (i == 0 && j == 6 && estado == 1) { BTNA7.BackColor = Color.Red; }
            if (i == 0 && j == 7 && estado == 1) { BTNA8.BackColor = Color.Red; }
            if (i == 0 && j == 8 && estado == 1) { BTNA9.BackColor = Color.Red; }
            if (i == 0 && j == 9 && estado == 1) { BTNA10.BackColor = Color.Red; }
            if (i == 0 && j == 10 && estado == 1) { BTNA11.BackColor = Color.Red; }
            if (i == 0 && j == 11 && estado == 1) { BTNA12.BackColor = Color.Red; }
            if (i == 0 && j == 12 && estado == 1) { BTNA13.BackColor = Color.Red; }
            if (i == 0 && j == 13 && estado == 1) { BTNA14.BackColor = Color.Red; }
            if (i == 0 && j == 14 && estado == 1) { BTNA15.BackColor = Color.Red; }
            if (i == 1 && j == 0 && estado == 1) { BTNB1.BackColor = Color.Red; } 
            if (i == 1 && j == 1 && estado == 1) { BTNB2.BackColor = Color.Red; } 
            if (i == 1 && j == 2 && estado == 1) { BTNB3.BackColor = Color.Red; } 
            if (i == 1 && j == 3 && estado == 1) { BTNB4.BackColor = Color.Red; } 
            if (i == 1 && j == 4 && estado == 1) { BTNB5.BackColor = Color.Red; } 
            if (i == 1 && j == 5 && estado == 1) { BTNB6.BackColor = Color.Red; } 
            if (i == 1 && j == 6 && estado == 1) { BTNB7.BackColor = Color.Red; } 
            if (i == 1 && j == 7 && estado == 1) { BTNB8.BackColor = Color.Red; } 
            if (i == 1 && j == 8 && estado == 1) { BTNB9.BackColor = Color.Red; } 
            if (i == 1 && j == 9 && estado == 1) { BTNB10.BackColor = Color.Red; }
            if (i == 1 && j == 10 && estado == 1) { BTNB11.BackColor = Color.Red; } 
            if (i == 1 && j == 11 && estado == 1) { BTNB12.BackColor = Color.Red; } 
            if (i == 1 && j == 12 && estado == 1) { BTNB13.BackColor = Color.Red; } 
            if (i == 1 && j == 13 && estado == 1) { BTNB14.BackColor = Color.Red; } 
            if (i == 1 && j == 14 && estado == 1) { BTNB15.BackColor = Color.Red; } 
            if (i == 2 && j == 0 && estado == 1) { BTNC1.BackColor = Color.Red; } 
            if (i == 2 && j == 1 && estado == 1) { BTNC2.BackColor = Color.Red; } 
            if (i == 2 && j == 2 && estado == 1) { BTNC3.BackColor = Color.Red; } 
            if (i == 2 && j == 3 && estado == 1) { BTNC4.BackColor = Color.Red; } 
            if (i == 2 && j == 4 && estado == 1) { BTNC5.BackColor = Color.Red; } 
            if (i == 2 && j == 5 && estado == 1) { BTNC6.BackColor = Color.Red; } 
            if (i == 2 && j == 6 && estado == 1) { BTNC7.BackColor = Color.Red; } 
            if (i == 2 && j == 7 && estado == 1) { BTNC8.BackColor = Color.Red; } 
            if (i == 2 && j == 8 && estado == 1) { BTNC9.BackColor = Color.Red; } 
            if (i == 2 && j == 9 && estado == 1) { BTNC10.BackColor = Color.Red; } 
            if (i == 2 && j == 10 && estado == 1) { BTNC11.BackColor = Color.Red; } 
            if (i == 2 && j == 11 && estado == 1) { BTNC12.BackColor = Color.Red; } 
            if (i == 2 && j == 12 && estado == 1) { BTNC13.BackColor = Color.Red; }
            if (i == 2 && j == 13 && estado == 1) { BTNC14.BackColor = Color.Red; }
            if (i == 2 && j == 14 && estado == 1) { BTNC15.BackColor = Color.Red; }
            if (i == 3 && j == 0 && estado == 1) { BTND1.BackColor = Color.Red; }
            if (i == 3 && j == 1 && estado == 1) { BTND2.BackColor = Color.Red; }
            if (i == 3 && j == 2 && estado == 1) { BTND3.BackColor = Color.Red; }
            if (i == 3 && j == 3 && estado == 1) { BTND4.BackColor = Color.Red; }
            if (i == 3 && j == 4 && estado == 1) { BTND5.BackColor = Color.Red; }
            if (i == 3 && j == 5 && estado == 1) { BTND6.BackColor = Color.Red; }
            if (i == 3 && j == 6 && estado == 1) { BTND7.BackColor = Color.Red; }
            if (i == 3 && j == 7 && estado == 1) { BTND8.BackColor = Color.Red; }
            if (i == 3 && j == 8 && estado == 1) { BTND9.BackColor = Color.Red; }
            if (i == 3 && j == 9 && estado == 1) { BTND10.BackColor = Color.Red; }
            if (i == 3 && j == 10 && estado == 1) { BTND11.BackColor = Color.Red; }
            if (i == 3 && j == 11 && estado == 1) { BTND12.BackColor = Color.Red; }
            if (i == 3 && j == 12 && estado == 1) { BTND13.BackColor = Color.Red; }
            if (i == 3 && j == 13 && estado == 1) { BTND14.BackColor = Color.Red; } 
            if (i == 3 && j == 14 && estado == 1) { BTND15.BackColor = Color.Red; }
            if (i == 4 && j == 0 && estado == 1) { BTNE1.BackColor = Color.Red; }   
            if (i == 4 && j == 1 && estado == 1) { BTNE2.BackColor = Color.Red; }
            if (i == 4 && j == 2 && estado == 1) { BTNE3.BackColor = Color.Red; }
            if (i == 4 && j == 3 && estado == 1) { BTNE4.BackColor = Color.Red; }
            if (i == 4 && j == 4 && estado == 1) { BTNE5.BackColor = Color.Red; }
            if (i == 4 && j == 5 && estado == 1) { BTNE6.BackColor = Color.Red; }
            if (i == 4 && j == 6 && estado == 1) { BTNE7.BackColor = Color.Red; }
            if (i == 4 && j == 7 && estado == 1) { BTNE8.BackColor = Color.Red; }
            if (i == 4 && j == 8 && estado == 1) { BTNE9.BackColor = Color.Red; }
            if (i == 4 && j == 9 && estado == 1) { BTNE10.BackColor = Color.Red; }
            if (i == 4 && j == 10 && estado == 1) { BTNE11.BackColor = Color.Red; }
            if (i == 4 && j == 11 && estado == 1) { BTNE12.BackColor = Color.Red; }
            if (i == 4 && j == 12 && estado == 1) { BTNE13.BackColor = Color.Red; }
            if (i == 4 && j == 13 && estado == 1) { BTNE14.BackColor = Color.Red; } 
            if (i == 4 && j == 14 && estado == 1) { BTNE15.BackColor = Color.Red; }
            if (i == 5 && j == 0 && estado == 1) { BTNF1.BackColor = Color.Red; }
            if (i == 5 && j == 1 && estado == 1) { BTNF2.BackColor = Color.Red; }   
            if (i == 5 && j == 2 && estado == 1) { BTNF3.BackColor = Color.Red; }
            if (i == 5 && j == 3 && estado == 1) { BTNF4.BackColor = Color.Red; }
            if (i == 5 && j == 4 && estado == 1) { BTNF5.BackColor = Color.Red; }
            if (i == 5 && j == 5 && estado == 1) { BTNF6.BackColor = Color.Red; }
            if (i == 5 && j == 6 && estado == 1) { BTNF7.BackColor = Color.Red; }
            if (i == 5 && j == 7 && estado == 1) { BTNF8.BackColor = Color.Red; }
            if (i == 5 && j == 8 && estado == 1) { BTNF9.BackColor = Color.Red; }
            if (i == 5 && j == 9 && estado == 1) { BTNF10.BackColor = Color.Red; }
            if (i == 5 && j == 10 && estado == 1) { BTNF11.BackColor = Color.Red; }
            if (i == 5 && j == 11 && estado == 1) { BTNF12.BackColor = Color.Red; }
            if (i == 5 && j == 12 && estado == 1) { BTNF13.BackColor = Color.Red; }
            if (i == 5 && j == 13 && estado == 1) { BTNF14.BackColor = Color.Red; }
            if (i == 5 && j == 14 && estado == 1) { BTNF15.BackColor = Color.Red; }
            if (i == 6 && j == 0 && estado == 1) { BTNG1.BackColor = Color.Red; }
            if (i == 6 && j == 1 && estado == 1) { BTNG2.BackColor = Color.Red; }
            if (i == 6 && j == 2 && estado == 1) { BTNG3.BackColor = Color.Red; }
            if (i == 6 && j == 3 && estado == 1) { BTNG4.BackColor = Color.Red; }
            if (i == 6 && j == 4 && estado == 1) { BTNG5.BackColor = Color.Red; }
            if (i == 6 && j == 5 && estado == 1) { BTNG6.BackColor = Color.Red; }
            if (i == 6 && j == 6 && estado == 1) { BTNG7.BackColor = Color.Red; }
            if (i == 6 && j == 7 && estado == 1) { BTNG8.BackColor = Color.Red; }
            if (i == 6 && j == 8 && estado == 1) { BTNG9.BackColor = Color.Red; }
            if (i == 6 && j == 9 && estado == 1) { BTNG10.BackColor = Color.Red; }
            if (i == 6 && j == 10 && estado == 1) { BTNG11.BackColor = Color.Red; }
            if (i == 6 && j == 11 && estado == 1) { BTNG12.BackColor = Color.Red; }
            if (i == 6 && j == 12 && estado == 1) { BTNG13.BackColor = Color.Red; }
            if (i == 6 && j == 13 && estado == 1) { BTNG14.BackColor = Color.Red; }
            if (i == 6 && j == 14 && estado == 1) { BTNG15.BackColor = Color.Red; }
            if (i == 7 && j == 0 && estado == 1) { BTNH1.BackColor = Color.Red; }
            if (i == 7 && j == 1 && estado == 1) { BTNH2.BackColor = Color.Red; }
            if (i == 7 && j == 2 && estado == 1) { BTNH3.BackColor = Color.Red; }
            if (i == 7 && j == 3 && estado == 1) { BTNH4.BackColor = Color.Red; }
            if (i == 7 && j == 4 && estado == 1) { BTNH5.BackColor = Color.Red; }
            if (i == 7 && j == 5 && estado == 1) { BTNH6.BackColor = Color.Red; }
            if (i == 7 && j == 6 && estado == 1) { BTNH7.BackColor = Color.Red; }
            if (i == 7 && j == 7 && estado == 1) { BTNH8.BackColor = Color.Red; }
            if (i == 7 && j == 8 && estado == 1) { BTNH9.BackColor = Color.Red; }
            if (i == 7 && j == 9 && estado == 1) { BTNH10.BackColor = Color.Red; }
            if (i == 7 && j == 10 && estado == 1) { BTNH11.BackColor = Color.Red; }
            if (i == 7 && j == 11 && estado == 1) { BTNH12.BackColor = Color.Red; }
            if (i == 7 && j == 12 && estado == 1) { BTNH13.BackColor = Color.Red; }
            if (i == 7 && j == 13 && estado == 1) { BTNH14.BackColor = Color.Red; }
            if (i == 7 && j == 14 && estado == 1) { BTNH15.BackColor = Color.Red; }
            if (i == 8 && j == 0 && estado == 1) { BTNI1.BackColor = Color.Red; }
            if (i == 8 && j == 1 && estado == 1) { BTNI2.BackColor = Color.Red; }
            if (i == 8 && j == 2 && estado == 1) { BTNI3.BackColor = Color.Red; }
            if (i == 8 && j == 3 && estado == 1) { BTNI4.BackColor = Color.Red; }
            if (i == 8 && j == 4 && estado == 1) { BTNI5.BackColor = Color.Red; }
            if (i == 8 && j == 5 && estado == 1) { BTNI6.BackColor = Color.Red; }
            if (i == 8 && j == 6 && estado == 1) { BTNI7.BackColor = Color.Red; }
            if (i == 8 && j == 7 && estado == 1) { BTNI8.BackColor = Color.Red; }
            if (i == 8 && j == 8 && estado == 1) { BTNI9.BackColor = Color.Red; }
            if (i == 8 && j == 9 && estado == 1) { BTNI10.BackColor = Color.Red; }
            if (i == 8 && j == 10 && estado == 1) { BTNI11.BackColor = Color.Red; }
            if (i == 8 && j == 11 && estado == 1) { BTNI12.BackColor = Color.Red; }
            if (i == 8 && j == 12 && estado == 1) { BTNI13.BackColor = Color.Red; }
            if (i == 8 && j == 13 && estado == 1) { BTNI14.BackColor = Color.Red; }
            if (i == 8 && j == 14 && estado == 1) { BTNI15.BackColor = Color.Red; }
            if (i == 9 && j == 0 && estado == 1) { BTNJ1.BackColor = Color.Red; }
            if (i == 9 && j == 1 && estado == 1) { BTNJ2.BackColor = Color.Red; }
            if (i == 9 && j == 2 && estado == 1) { BTNJ3.BackColor = Color.Red; }
            if (i == 9 && j == 3 && estado == 1) { BTNJ4.BackColor = Color.Red; }
            if (i == 9 && j == 4 && estado == 1) { BTNJ5.BackColor = Color.Red; }
            if (i == 9 && j == 5 && estado == 1) { BTNJ6.BackColor = Color.Red; }
            if (i == 9 && j == 6 && estado == 1) { BTNJ7.BackColor = Color.Red; }
            if (i == 9 && j == 7 && estado == 1) { BTNJ8.BackColor = Color.Red; }
            if (i == 9 && j == 8 && estado == 1) { BTNJ9.BackColor = Color.Red; }
            if (i == 9 && j == 9 && estado == 1) { BTNJ10.BackColor = Color.Red; }
            if (i == 9 && j == 10 && estado == 1) { BTNJ11.BackColor = Color.Red; }
            if (i == 9 && j == 11 && estado == 1) { BTNJ12.BackColor = Color.Red; }
            if (i == 9 && j == 12 && estado == 1) { BTNJ13.BackColor = Color.Red; }
            if (i == 9 && j == 13 && estado == 1) { BTNJ14.BackColor = Color.Red; }
            if (i == 9 && j == 14 && estado == 1) { BTNJ15.BackColor = Color.Red; }

            //sino
            if (i == 0 && j == 0 && estado == 0) { BTNA1.BackColor = Color.LightGreen; }
            if (i == 0 && j == 1 && estado == 0) { BTNA2.BackColor = Color.LightGreen; }
            if (i == 0 && j == 2 && estado == 0) { BTNA3.BackColor = Color.LightGreen; }
            if (i == 0 && j == 3 && estado == 0) { BTNA4.BackColor = Color.LightGreen; }
            if (i == 0 && j == 4 && estado == 0) { BTNA5.BackColor = Color.LightGreen; }
            if (i == 0 && j == 5 && estado == 0) { BTNA6.BackColor = Color.LightGreen; }
            if (i == 0 && j == 6 && estado == 0) { BTNA7.BackColor = Color.LightGreen; }
            if (i == 0 && j == 7 && estado == 0) { BTNA8.BackColor = Color.LightGreen; }
            if (i == 0 && j == 8 && estado == 0) { BTNA9.BackColor = Color.LightGreen; }
            if (i == 0 && j == 9 && estado == 0) { BTNA10.BackColor = Color.LightGreen; }
            if (i == 0 && j == 10 && estado == 0) { BTNA11.BackColor = Color.LightGreen; }
            if (i == 0 && j == 11 && estado == 0) { BTNA12.BackColor = Color.LightGreen; }
            if (i == 0 && j == 12 && estado == 0) { BTNA13.BackColor = Color.LightGreen; }
            if (i == 0 && j == 13 && estado == 0) { BTNA14.BackColor = Color.LightGreen; }
            if (i == 0 && j == 14 && estado == 0) { BTNA15.BackColor = Color.LightGreen; }
            if (i == 1 && j == 0 && estado == 0) { BTNB1.BackColor = Color.LightGreen; }
            if (i == 1 && j == 1 && estado == 0) { BTNB2.BackColor = Color.LightGreen; }
            if (i == 1 && j == 2 && estado == 0) { BTNB3.BackColor = Color.LightGreen; }
            if (i == 1 && j == 3 && estado == 0) { BTNB4.BackColor = Color.LightGreen; }
            if (i == 1 && j == 4 && estado == 0) { BTNB5.BackColor = Color.LightGreen; }
            if (i == 1 && j == 5 && estado == 0) { BTNB6.BackColor = Color.LightGreen; }
            if (i == 1 && j == 6 && estado == 0) { BTNB7.BackColor = Color.LightGreen; }
            if (i == 1 && j == 7 && estado == 0) { BTNB8.BackColor = Color.LightGreen; }
            if (i == 1 && j == 8 && estado == 0) { BTNB9.BackColor = Color.LightGreen; }
            if (i == 1 && j == 9 && estado == 0) { BTNB10.BackColor = Color.LightGreen; }
            if (i == 1 && j == 10 && estado == 0) { BTNB11.BackColor = Color.LightGreen; }
            if (i == 1 && j == 11 && estado == 0) { BTNB12.BackColor = Color.LightGreen; }
            if (i == 1 && j == 12 && estado == 0) { BTNB13.BackColor = Color.LightGreen; }
            if (i == 1 && j == 13 && estado == 0) { BTNB14.BackColor = Color.LightGreen; }
            if (i == 1 && j == 14 && estado == 0) { BTNB15.BackColor = Color.LightGreen; }
            if (i == 2 && j == 0 && estado == 0) { BTNC1.BackColor = Color.LightGreen; }
            if (i == 2 && j == 1 && estado == 0) { BTNC2.BackColor = Color.LightGreen; }
            if (i == 2 && j == 2 && estado == 0) { BTNC3.BackColor = Color.LightGreen; }
            if (i == 2 && j == 3 && estado == 0) { BTNC4.BackColor = Color.LightGreen; }
            if (i == 2 && j == 4 && estado == 0) { BTNC5.BackColor = Color.LightGreen; }
            if (i == 2 && j == 5 && estado == 0) { BTNC6.BackColor = Color.LightGreen; }
            if (i == 2 && j == 6 && estado == 0) { BTNC7.BackColor = Color.LightGreen; }
            if (i == 2 && j == 7 && estado == 0) { BTNC8.BackColor = Color.LightGreen; }
            if (i == 2 && j == 8 && estado == 0) { BTNC9.BackColor = Color.LightGreen; }
            if (i == 2 && j == 9 && estado == 0) { BTNC10.BackColor = Color.LightGreen; }
            if (i == 2 && j == 10 && estado == 0) { BTNC11.BackColor = Color.LightGreen; }
            if (i == 2 && j == 11 && estado == 0) { BTNC12.BackColor = Color.LightGreen; }
            if (i == 2 && j == 12 && estado == 0) { BTNC13.BackColor = Color.LightGreen; }
            if (i == 2 && j == 13 && estado == 0) { BTNC14.BackColor = Color.LightGreen; }
            if (i == 2 && j == 14 && estado == 0) { BTNC15.BackColor = Color.LightGreen; }
            if (i == 3 && j == 0 && estado == 0) { BTND1.BackColor = Color.LightGreen; }
            if (i == 3 && j == 1 && estado == 0) { BTND2.BackColor = Color.LightGreen; }
            if (i == 3 && j == 2 && estado == 0) { BTND3.BackColor = Color.LightGreen; }
            if (i == 3 && j == 3 && estado == 0) { BTND4.BackColor = Color.LightGreen; }
            if (i == 3 && j == 4 && estado == 0) { BTND5.BackColor = Color.LightGreen; }
            if (i == 3 && j == 5 && estado == 0) { BTND6.BackColor = Color.LightGreen; }
            if (i == 3 && j == 6 && estado == 0) { BTND7.BackColor = Color.LightGreen; }
            if (i == 3 && j == 7 && estado == 0) { BTND8.BackColor = Color.LightGreen; }
            if (i == 3 && j == 8 && estado == 0) { BTND9.BackColor = Color.LightGreen; }
            if (i == 3 && j == 9 && estado == 0) { BTND10.BackColor = Color.LightGreen; }
            if (i == 3 && j == 10 && estado == 0) { BTND11.BackColor = Color.LightGreen; }
            if (i == 3 && j == 11 && estado == 0) { BTND12.BackColor = Color.LightGreen; }
            if (i == 3 && j == 12 && estado == 0) { BTND13.BackColor = Color.LightGreen; }
            if (i == 3 && j == 13 && estado == 0) { BTND14.BackColor = Color.LightGreen; }
            if (i == 3 && j == 14 && estado == 0) { BTND15.BackColor = Color.LightGreen; }
            if (i == 4 && j == 0 && estado == 0) { BTNE1.BackColor = Color.LightGreen; }
            if (i == 4 && j == 1 && estado == 0) { BTNE2.BackColor = Color.LightGreen; }
            if (i == 4 && j == 2 && estado == 0) { BTNE3.BackColor = Color.LightGreen; }
            if (i == 4 && j == 3 && estado == 0) { BTNE4.BackColor = Color.LightGreen; }
            if (i == 4 && j == 4 && estado == 0) { BTNE5.BackColor = Color.LightGreen; }
            if (i == 4 && j == 5 && estado == 0) { BTNE6.BackColor = Color.LightGreen; }
            if (i == 4 && j == 6 && estado == 0) { BTNE7.BackColor = Color.LightGreen; }
            if (i == 4 && j == 7 && estado == 0) { BTNE8.BackColor = Color.LightGreen; }
            if (i == 4 && j == 8 && estado == 0) { BTNE9.BackColor = Color.LightGreen; }
            if (i == 4 && j == 9 && estado == 0) { BTNE10.BackColor = Color.LightGreen; }
            if (i == 4 && j == 10 && estado == 0) { BTNE11.BackColor = Color.LightGreen; }
            if (i == 4 && j == 11 && estado == 0) { BTNE12.BackColor = Color.LightGreen; }
            if (i == 4 && j == 12 && estado == 0) { BTNE13.BackColor = Color.LightGreen; }
            if (i == 4 && j == 13 && estado == 0) { BTNE14.BackColor = Color.LightGreen; }
            if (i == 4 && j == 14 && estado == 0) { BTNE15.BackColor = Color.LightGreen; }
            if (i == 5 && j == 0 && estado == 0) { BTNF1.BackColor = Color.LightGreen; }
            if (i == 5 && j == 1 && estado == 0) { BTNF2.BackColor = Color.LightGreen; }
            if (i == 5 && j == 2 && estado == 0) { BTNF3.BackColor = Color.LightGreen; }
            if (i == 5 && j == 3 && estado == 0) { BTNF4.BackColor = Color.LightGreen; }
            if (i == 5 && j == 4 && estado == 0) { BTNF5.BackColor = Color.LightGreen; }
            if (i == 5 && j == 5 && estado == 0) { BTNF6.BackColor = Color.LightGreen; }
            if (i == 5 && j == 6 && estado == 0) { BTNF7.BackColor = Color.LightGreen; }
            if (i == 5 && j == 7 && estado == 0) { BTNF8.BackColor = Color.LightGreen; }
            if (i == 5 && j == 8 && estado == 0) { BTNF9.BackColor = Color.LightGreen; }
            if (i == 5 && j == 9 && estado == 0) { BTNF10.BackColor = Color.LightGreen; }
            if (i == 5 && j == 10 && estado == 0) { BTNF11.BackColor = Color.LightGreen; }
            if (i == 5 && j == 11 && estado == 0) { BTNF12.BackColor = Color.LightGreen; }
            if (i == 5 && j == 12 && estado == 0) { BTNF13.BackColor = Color.LightGreen; }
            if (i == 5 && j == 13 && estado == 0) { BTNF14.BackColor = Color.LightGreen; }
            if (i == 5 && j == 14 && estado == 0) { BTNF15.BackColor = Color.LightGreen; }
            if (i == 6 && j == 0 && estado == 0) { BTNG1.BackColor = Color.LightGreen; }
            if (i == 6 && j == 1 && estado == 0) { BTNG2.BackColor = Color.LightGreen; }
            if (i == 6 && j == 2 && estado == 0) { BTNG3.BackColor = Color.LightGreen; }
            if (i == 6 && j == 3 && estado == 0) { BTNG4.BackColor = Color.LightGreen; }
            if (i == 6 && j == 4 && estado == 0) { BTNG5.BackColor = Color.LightGreen; }
            if (i == 6 && j == 5 && estado == 0) { BTNG6.BackColor = Color.LightGreen; }
            if (i == 6 && j == 6 && estado == 0) { BTNG7.BackColor = Color.LightGreen; }
            if (i == 6 && j == 7 && estado == 0) { BTNG8.BackColor = Color.LightGreen; }
            if (i == 6 && j == 8 && estado == 0) { BTNG9.BackColor = Color.LightGreen; }
            if (i == 6 && j == 9 && estado == 0) { BTNG10.BackColor = Color.LightGreen; }
            if (i == 6 && j == 10 && estado == 0) { BTNG11.BackColor = Color.LightGreen; }
            if (i == 6 && j == 11 && estado == 0) { BTNG12.BackColor = Color.LightGreen; }
            if (i == 6 && j == 12 && estado == 0) { BTNG13.BackColor = Color.LightGreen; }
            if (i == 6 && j == 13 && estado == 0) { BTNG14.BackColor = Color.LightGreen; }
            if (i == 6 && j == 14 && estado == 0) { BTNG15.BackColor = Color.LightGreen; }
            if (i == 7 && j == 0 && estado == 0) { BTNH1.BackColor = Color.LightGreen; }
            if (i == 7 && j == 1 && estado == 0) { BTNH2.BackColor = Color.LightGreen; }
            if (i == 7 && j == 2 && estado == 0) { BTNH3.BackColor = Color.LightGreen; }
            if (i == 7 && j == 3 && estado == 0) { BTNH4.BackColor = Color.LightGreen; }
            if (i == 7 && j == 4 && estado == 0) { BTNH5.BackColor = Color.LightGreen; }
            if (i == 7 && j == 5 && estado == 0) { BTNH6.BackColor = Color.LightGreen; }
            if (i == 7 && j == 6 && estado == 0) { BTNH7.BackColor = Color.LightGreen; }
            if (i == 7 && j == 7 && estado == 0) { BTNH8.BackColor = Color.LightGreen; }
            if (i == 7 && j == 8 && estado == 0) { BTNH9.BackColor = Color.LightGreen; }
            if (i == 7 && j == 9 && estado == 0) { BTNH10.BackColor = Color.LightGreen; }
            if (i == 7 && j == 10 && estado == 0) { BTNH11.BackColor = Color.LightGreen; }
            if (i == 7 && j == 11 && estado == 0) { BTNH12.BackColor = Color.LightGreen; }
            if (i == 7 && j == 12 && estado == 0) { BTNH13.BackColor = Color.LightGreen; }
            if (i == 7 && j == 13 && estado == 0) { BTNH14.BackColor = Color.LightGreen; }
            if (i == 7 && j == 14 && estado == 0) { BTNH15.BackColor = Color.LightGreen; }
            if (i == 8 && j == 0 && estado == 0) { BTNI1.BackColor = Color.LightGreen; }
            if (i == 8 && j == 1 && estado == 0) { BTNI2.BackColor = Color.LightGreen; }
            if (i == 8 && j == 2 && estado == 0) { BTNI3.BackColor = Color.LightGreen; }
            if (i == 8 && j == 3 && estado == 0) { BTNI4.BackColor = Color.LightGreen; }
            if (i == 8 && j == 4 && estado == 0) { BTNI5.BackColor = Color.LightGreen; }
            if (i == 8 && j == 5 && estado == 0) { BTNI6.BackColor = Color.LightGreen; }
            if (i == 8 && j == 6 && estado == 0) { BTNI7.BackColor = Color.LightGreen; }
            if (i == 8 && j == 7 && estado == 0) { BTNI8.BackColor = Color.LightGreen; }
            if (i == 8 && j == 8 && estado == 0) { BTNI9.BackColor = Color.LightGreen; }
            if (i == 8 && j == 9 && estado == 0) { BTNI10.BackColor = Color.LightGreen; }
            if (i == 8 && j == 10 && estado == 0) { BTNI11.BackColor = Color.LightGreen; }
            if (i == 8 && j == 11 && estado == 0) { BTNI12.BackColor = Color.LightGreen; }
            if (i == 8 && j == 12 && estado == 0) { BTNI13.BackColor = Color.LightGreen; }
            if (i == 8 && j == 13 && estado == 0) { BTNI14.BackColor = Color.LightGreen; }
            if (i == 8 && j == 14 && estado == 0) { BTNI15.BackColor = Color.LightGreen; }
            if (i == 9 && j == 0 && estado == 0) { BTNJ1.BackColor = Color.LightGreen; }
            if (i == 9 && j == 1 && estado == 0) { BTNJ2.BackColor = Color.LightGreen; }
            if (i == 9 && j == 2 && estado == 0) { BTNJ3.BackColor = Color.LightGreen; }
            if (i == 9 && j == 3 && estado == 0) { BTNJ4.BackColor = Color.LightGreen; }
            if (i == 9 && j == 4 && estado == 0) { BTNJ5.BackColor = Color.LightGreen; }
            if (i == 9 && j == 5 && estado == 0) { BTNJ6.BackColor = Color.LightGreen; }
            if (i == 9 && j == 6 && estado == 0) { BTNJ7.BackColor = Color.LightGreen; }
            if (i == 9 && j == 7 && estado == 0) { BTNJ8.BackColor = Color.LightGreen; }
            if (i == 9 && j == 8 && estado == 0) { BTNJ9.BackColor = Color.LightGreen; }
            if (i == 9 && j == 9 && estado == 0) { BTNJ10.BackColor = Color.LightGreen; }
            if (i == 9 && j == 10 && estado == 0) { BTNJ11.BackColor = Color.LightGreen; }
            if (i == 9 && j == 11 && estado == 0) { BTNJ12.BackColor = Color.LightGreen; }
            if (i == 9 && j == 12 && estado == 0) { BTNJ13.BackColor = Color.LightGreen; }
            if (i == 9 && j == 13 && estado == 0) { BTNJ14.BackColor = Color.LightGreen; }
            if (i == 9 && j == 14 && estado == 0) { BTNJ15.BackColor = Color.LightGreen; }
        }


        private void Form1_Load(object sender, EventArgs e)
        {  
            int x,y,estado = 0;            
            LimpiarPantalla();
            ConexionDB conexion = new ConexionDB();            
            conexion.abrir();
            for (x = 0; x < 10; x++)
            {
                for (y = 0; y < 15; y++)
                {
                    estado = conexion.EstadoAsiento(x, y);
                    ActualizaAsientos(x,y,estado);
                }
            }
            //conexion.Reservar(1,2);           
            conexion.cerrar();
           
        }

        private void BTNA5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA5.Name);
            Columna = conexion.AsientoC(BTNA5.Name);
            fi = BTNA5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA6.Name);
            Columna = conexion.AsientoC(BTNA6.Name);
            fi = BTNA6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA7.Name);
            Columna = conexion.AsientoC(BTNA7.Name);
            fi = BTNA7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA8.Name);
            Columna = conexion.AsientoC(BTNA8.Name);
            fi = BTNA8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA9.Name);
            Columna = conexion.AsientoC(BTNA9.Name);
            fi = BTNA9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA10.Name);
            Columna = conexion.AsientoC(BTNA10.Name);
            fi = BTNA10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA11.Name);
            Columna = conexion.AsientoC(BTNA11.Name);
            fi = BTNA11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA12.Name);
            Columna = conexion.AsientoC(BTNA12.Name);
            fi = BTNA12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA13.Name);
            Columna = conexion.AsientoC(BTNA13.Name);
            fi = BTNA13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA14.Name);
            Columna = conexion.AsientoC(BTNA14.Name);
            fi = BTNA14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNA15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNA15.Name);
            Columna = conexion.AsientoC(BTNA15.Name);
            fi = BTNA15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNA15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB1.Name);
            Columna = conexion.AsientoC(BTNB1.Name);
            fi = BTNB1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB2.Name);
            Columna = conexion.AsientoC(BTNB2.Name);
            fi = BTNB2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB3.Name);
            Columna = conexion.AsientoC(BTNB3.Name);
            fi = BTNB3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB4.Name);
            Columna = conexion.AsientoC(BTNB4.Name);
            fi = BTNB4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB5.Name);
            Columna = conexion.AsientoC(BTNB5.Name);
            fi = BTNB5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB6.Name);
            Columna = conexion.AsientoC(BTNB6.Name);
            fi = BTNB6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB7.Name);
            Columna = conexion.AsientoC(BTNB7.Name);
            fi = BTNB7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB8.Name);
            Columna = conexion.AsientoC(BTNB8.Name);
            fi = BTNB8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB9.Name);
            Columna = conexion.AsientoC(BTNB9.Name);
            fi = BTNB9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB10.Name);
            Columna = conexion.AsientoC(BTNB10.Name);
            fi = BTNB10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB11.Name);
            Columna = conexion.AsientoC(BTNB11.Name);
            fi = BTNB11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB12.Name);
            Columna = conexion.AsientoC(BTNB12.Name);
            fi = BTNB12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB13.Name);
            Columna = conexion.AsientoC(BTNB13.Name);
            fi = BTNB13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB14.Name);
            Columna = conexion.AsientoC(BTNB14.Name);
            fi = BTNB14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNB15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNB15.Name);
            Columna = conexion.AsientoC(BTNB15.Name);
            fi = BTNB15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNB15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC1.Name);
            Columna = conexion.AsientoC(BTNC1.Name);
            fi = BTNC1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC2.Name);
            Columna = conexion.AsientoC(BTNC2.Name);
            fi = BTNC2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC3.Name);
            Columna = conexion.AsientoC(BTNC3.Name);
            fi = BTNC3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC4.Name);
            Columna = conexion.AsientoC(BTNC4.Name);
            fi = BTNC4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC5.Name);
            Columna = conexion.AsientoC(BTNC5.Name);
            fi = BTNC5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC6.Name);
            Columna = conexion.AsientoC(BTNC6.Name);
            fi = BTNC6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC7.Name);
            Columna = conexion.AsientoC(BTNC7.Name);
            fi = BTNC7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC8.Name);
            Columna = conexion.AsientoC(BTNC8.Name);
            fi = BTNC8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC9.Name);
            Columna = conexion.AsientoC(BTNC9.Name);
            fi = BTNC9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC10.Name);
            Columna = conexion.AsientoC(BTNC10.Name);
            fi = BTNC10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC11.Name);
            Columna = conexion.AsientoC(BTNC11.Name);
            fi = BTNC11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC12.Name);
            Columna = conexion.AsientoC(BTNC12.Name);
            fi = BTNC12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC13.Name);
            Columna = conexion.AsientoC(BTNC13.Name);
            fi = BTNC13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC14.Name);
            Columna = conexion.AsientoC(BTNC14.Name);
            fi = BTNC14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNC15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNC15.Name);
            Columna = conexion.AsientoC(BTNC15.Name);
            fi = BTNC15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNC15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND1.Name);
            Columna = conexion.AsientoC(BTND1.Name);
            fi = BTND1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND2.Name);
            Columna = conexion.AsientoC(BTND2.Name);
            fi = BTND2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND3.Name);
            Columna = conexion.AsientoC(BTND3.Name);
            fi = BTND3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND4.Name);
            Columna = conexion.AsientoC(BTND4.Name);
            fi = BTND4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND5.Name);
            Columna = conexion.AsientoC(BTND5.Name);
            fi = BTND5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND6.Name);
            Columna = conexion.AsientoC(BTND6.Name);
            fi = BTND6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND7.Name);
            Columna = conexion.AsientoC(BTND7.Name);
            fi = BTND7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND8.Name);
            Columna = conexion.AsientoC(BTND8.Name);
            fi = BTND8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND9.Name);
            Columna = conexion.AsientoC(BTND9.Name);
            fi = BTND9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND10.Name);
            Columna = conexion.AsientoC(BTND10.Name);
            fi = BTND10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND11.Name);
            Columna = conexion.AsientoC(BTND11.Name);
            fi = BTND11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND12.Name);
            Columna = conexion.AsientoC(BTND12.Name);
            fi = BTND12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND13.Name);
            Columna = conexion.AsientoC(BTND13.Name);
            fi = BTND13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND14.Name);
            Columna = conexion.AsientoC(BTND14.Name);
            fi = BTND14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTND15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTND15.Name);
            Columna = conexion.AsientoC(BTND15.Name);
            fi = BTND15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTND15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE1.Name);
            Columna = conexion.AsientoC(BTNE1.Name);
            fi = BTNE1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE2.Name);
            Columna = conexion.AsientoC(BTNE2.Name);
            fi = BTNE2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE3.Name);
            Columna = conexion.AsientoC(BTNE3.Name);
            fi = BTNE3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE4.Name);
            Columna = conexion.AsientoC(BTNE4.Name);
            fi = BTNE4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE5.Name);
            Columna = conexion.AsientoC(BTNE5.Name);
            fi = BTNE5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE6.Name);
            Columna = conexion.AsientoC(BTNE6.Name);
            fi = BTNE6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE7.Name);
            Columna = conexion.AsientoC(BTNE7.Name);
            fi = BTNE7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE8.Name);
            Columna = conexion.AsientoC(BTNE8.Name);
            fi = BTNE8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE9.Name);
            Columna = conexion.AsientoC(BTNE9.Name);
            fi = BTNE9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE10.Name);
            Columna = conexion.AsientoC(BTNE10.Name);
            fi = BTNE10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE11.Name);
            Columna = conexion.AsientoC(BTNE11.Name);
            fi = BTNE11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE12.Name);
            Columna = conexion.AsientoC(BTNE12.Name);
            fi = BTNE12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE13.Name);
            Columna = conexion.AsientoC(BTNE13.Name);
            fi = BTNE13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE14.Name);
            Columna = conexion.AsientoC(BTNE14.Name);
            fi = BTNE14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNE15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNE15.Name);
            Columna = conexion.AsientoC(BTNE15.Name);
            fi = BTNE15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNE15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF1.Name);
            Columna = conexion.AsientoC(BTNF1.Name);
            fi = BTNF1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF2.Name);
            Columna = conexion.AsientoC(BTNF2.Name);
            fi = BTNF2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF3.Name);
            Columna = conexion.AsientoC(BTNF3.Name);
            fi = BTNF3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF4.Name);
            Columna = conexion.AsientoC(BTNF4.Name);
            fi = BTNF4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF5.Name);
            Columna = conexion.AsientoC(BTNF5.Name);
            fi = BTNF5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF6.Name);
            Columna = conexion.AsientoC(BTNF6.Name);
            fi = BTNF6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF7.Name);
            Columna = conexion.AsientoC(BTNF7.Name);
            fi = BTNF7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF8.Name);
            Columna = conexion.AsientoC(BTNF8.Name);
            fi = BTNF8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF9.Name);
            Columna = conexion.AsientoC(BTNF9.Name);
            fi = BTNF9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF10.Name);
            Columna = conexion.AsientoC(BTNF10.Name);
            fi = BTNF10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF11.Name);
            Columna = conexion.AsientoC(BTNF11.Name);
            fi = BTNF11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF12.Name);
            Columna = conexion.AsientoC(BTNF12.Name);
            fi = BTNF12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF13.Name);
            Columna = conexion.AsientoC(BTNF13.Name);
            fi = BTNF13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF14.Name);
            Columna = conexion.AsientoC(BTNF14.Name);
            fi = BTNF14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNF15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNF15.Name);
            Columna = conexion.AsientoC(BTNF15.Name);
            fi = BTNF15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNF15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG1.Name);
            Columna = conexion.AsientoC(BTNG1.Name);
            fi = BTNG1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG2.Name);
            Columna = conexion.AsientoC(BTNG2.Name);
            fi = BTNG2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG3.Name);
            Columna = conexion.AsientoC(BTNG3.Name);
            fi = BTNG3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG4.Name);
            Columna = conexion.AsientoC(BTNG4.Name);
            fi = BTNG4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG5.Name);
            Columna = conexion.AsientoC(BTNG5.Name);
            fi = BTNG5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG6.Name);
            Columna = conexion.AsientoC(BTNG6.Name);
            fi = BTNG6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG7.Name);
            Columna = conexion.AsientoC(BTNG7.Name);
            fi = BTNG7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG8.Name);
            Columna = conexion.AsientoC(BTNG8.Name);
            fi = BTNG8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG9.Name);
            Columna = conexion.AsientoC(BTNG9.Name);
            fi = BTNG9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG10.Name);
            Columna = conexion.AsientoC(BTNG10.Name);
            fi = BTNG10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG11.Name);
            Columna = conexion.AsientoC(BTNG11.Name);
            fi = BTNG11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG12.Name);
            Columna = conexion.AsientoC(BTNG12.Name);
            fi = BTNG12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG13.Name);
            Columna = conexion.AsientoC(BTNG13.Name);
            fi = BTNG13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG14.Name);
            Columna = conexion.AsientoC(BTNG14.Name);
            fi = BTNG14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNG15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNG15.Name);
            Columna = conexion.AsientoC(BTNG15.Name);
            fi = BTNG15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNG15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH1.Name);
            Columna = conexion.AsientoC(BTNH1.Name);
            fi = BTNH1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH2.Name);
            Columna = conexion.AsientoC(BTNH2.Name);
            fi = BTNH2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH3.Name);
            Columna = conexion.AsientoC(BTNH3.Name);
            fi = BTNH3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH4.Name);
            Columna = conexion.AsientoC(BTNH4.Name);
            fi = BTNH4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH5.Name);
            Columna = conexion.AsientoC(BTNH5.Name);
            fi = BTNH5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH6.Name);
            Columna = conexion.AsientoC(BTNH6.Name);
            fi = BTNH6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH7.Name);
            Columna = conexion.AsientoC(BTNH7.Name);
            fi = BTNH7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH8.Name);
            Columna = conexion.AsientoC(BTNH8.Name);
            fi = BTNH8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH9.Name);
            Columna = conexion.AsientoC(BTNH9.Name);
            fi = BTNH9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH10.Name);
            Columna = conexion.AsientoC(BTNH10.Name);
            fi = BTNH10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH11.Name);
            Columna = conexion.AsientoC(BTNH11.Name);
            fi = BTNH11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH12.Name);
            Columna = conexion.AsientoC(BTNH12.Name);
            fi = BTNH12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH13.Name);
            Columna = conexion.AsientoC(BTNH13.Name);
            fi = BTNH13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH14.Name);
            Columna = conexion.AsientoC(BTNH14.Name);
            fi = BTNH14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNH15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNH15.Name);
            Columna = conexion.AsientoC(BTNH15.Name);
            fi = BTNH15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNH15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI1.Name);
            Columna = conexion.AsientoC(BTNI1.Name);
            fi = BTNI1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI2.Name);
            Columna = conexion.AsientoC(BTNI2.Name);
            fi = BTNI2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI3.Name);
            Columna = conexion.AsientoC(BTNI3.Name);
            fi = BTNI3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI4.Name);
            Columna = conexion.AsientoC(BTNI4.Name);
            fi = BTNI4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI5.Name);
            Columna = conexion.AsientoC(BTNI5.Name);
            fi = BTNI5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI6.Name);
            Columna = conexion.AsientoC(BTNI6.Name);
            fi = BTNI6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI7.Name);
            Columna = conexion.AsientoC(BTNI7.Name);
            fi = BTNI7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI8.Name);
            Columna = conexion.AsientoC(BTNI8.Name);
            fi = BTNI8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI9.Name);
            Columna = conexion.AsientoC(BTNI9.Name);
            fi = BTNI9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI10.Name);
            Columna = conexion.AsientoC(BTNI10.Name);
            fi = BTNI10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI11.Name);
            Columna = conexion.AsientoC(BTNI11.Name);
            fi = BTNI11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI12.Name);
            Columna = conexion.AsientoC(BTNI12.Name);
            fi = BTNI12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI13.Name);
            Columna = conexion.AsientoC(BTNI13.Name);
            fi = BTNI13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI14.Name);
            Columna = conexion.AsientoC(BTNI14.Name);
            fi = BTNI14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNI15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNI15.Name);
            Columna = conexion.AsientoC(BTNI15.Name);
            fi = BTNI15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNI15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ1_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ1.Name);
            Columna = conexion.AsientoC(BTNJ1.Name);
            fi = BTNJ1.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ1.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ2_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ2.Name);
            Columna = conexion.AsientoC(BTNJ2.Name);
            fi = BTNJ2.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ2.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ3_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ3.Name);
            Columna = conexion.AsientoC(BTNJ3.Name);
            fi = BTNJ3.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ3.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ4_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ4.Name);
            Columna = conexion.AsientoC(BTNJ4.Name);
            fi = BTNJ4.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ4.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ5_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ5.Name);
            Columna = conexion.AsientoC(BTNJ5.Name);
            fi = BTNJ5.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ5.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ6_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ6.Name);
            Columna = conexion.AsientoC(BTNJ6.Name);
            fi = BTNJ6.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ6.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ7_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ7.Name);
            Columna = conexion.AsientoC(BTNJ7.Name);
            fi = BTNJ7.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ7.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ8_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ8.Name);
            Columna = conexion.AsientoC(BTNJ8.Name);
            fi = BTNJ8.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ8.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ9_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ9.Name);
            Columna = conexion.AsientoC(BTNJ9.Name);
            fi = BTNJ9.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ9.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ10_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ10.Name);
            Columna = conexion.AsientoC(BTNJ10.Name);
            fi = BTNJ10.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ10.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ11_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ11.Name);
            Columna = conexion.AsientoC(BTNJ11.Name);
            fi = BTNJ11.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ11.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ12_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ12.Name);
            Columna = conexion.AsientoC(BTNJ12.Name);
            fi = BTNJ12.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ12.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ13_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ13.Name);
            Columna = conexion.AsientoC(BTNJ13.Name);
            fi = BTNJ13.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ13.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ14_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ14.Name);
            Columna = conexion.AsientoC(BTNJ14.Name);
            fi = BTNJ14.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ14.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNJ15_Click(object sender, EventArgs e)
        {
            string fi, co = "";
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            Fila = conexion.AsientoF(BTNJ15.Name);
            Columna = conexion.AsientoC(BTNJ15.Name);
            fi = BTNJ15.Name.Substring(3, 1);
            Columna++;
            co = Columna.ToString();
            Columna = Columna - 1;
            TBnumeroasiento.Text = " " + fi + "-" + co;
            if (BTNJ15.BackColor == Color.LightGreen)
            {
                TBnombre.Text = "";
                TBestadoasiento.Text = ("DISPONIBLE");
                LBLaccion.Text = "Efectuar Reservación?";
            }
            else
            {
                TBestadoasiento.Text = ("OCUPADO");
                LBLaccion.Text = "Cancelar Reservación?";
                TBnombre.Text = conexion.NombreReserva(Fila, Columna);
            }
            conexion.cerrar();
        }

        private void BTNno_Click(object sender, EventArgs e)
        {
            LimpiarPantalla();
        }

        private void BTNsi_Click(object sender, EventArgs e)
        {
            int x,y,estado = 0;
            ConexionDB conexion = new ConexionDB();
            conexion.abrir();
            if (TBestadoasiento.Text == "DISPONIBLE")
            {
                if (TBnombre.Text != "")
                {                    
                    conexion.Reservar(Fila, Columna, TBnombre.Text);
                    for (x = 0; x < 10; x++)
                    {
                        for (y = 0; y < 15; y++)
                        {
                            estado = conexion.EstadoAsiento(x, y);
                            ActualizaAsientos(x, y, estado);
                        }
                    }                    
                    MessageBox.Show("La reserva se ha efectuado con éxito!", "Completado", MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show("El campo - Nombre Cliente - no puede estar vacío!", "Advertencia", MessageBoxButtons.OK);
                }
            }
            if (TBestadoasiento.Text == "OCUPADO")
            {
                conexion.CancelarReserva(Fila, Columna);
                for (x = 0; x < 10; x++)
                {
                    for (y = 0; y < 15; y++)
                    {
                        estado = conexion.EstadoAsiento(x, y);
                        ActualizaAsientos(x, y, estado);
                    }
                }
                MessageBox.Show("La cancelación se ha efectuado con éxito!", "Completado", MessageBoxButtons.OK);
            }
            if (TBestadoasiento.Text == "")
            {
                MessageBox.Show("No hay selección de asiento, por favor seleccione uno!", "No es posible!", MessageBoxButtons.OK);
            }
            LimpiarPantalla();
            conexion.cerrar();
        }

        private void button153_Click(object sender, EventArgs e)
        {            
            Close();
        }

        private void BTNlimpia_Click(object sender, EventArgs e)        
        {
            int x, y, estado = 0;
            DialogResult Resultado = MessageBox.Show("Esta acción elimina todas las reservas efectuadas... Desea proceder a borrar la información?", "Advertencia", MessageBoxButtons.YesNo);
            if (Resultado == DialogResult.Yes)               
            {
                ConexionDB conexion = new ConexionDB();
                conexion.abrir();
                conexion.BorrarDB();
                for (x = 0; x < 10; x++)
                {
                    for (y = 0; y < 15; y++)
                    {
                        estado = conexion.EstadoAsiento(x, y);
                        ActualizaAsientos(x, y, estado);
                    }
                }
                LimpiarPantalla();
            }
            
        }
    }
}
